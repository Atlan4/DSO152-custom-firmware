/* Open-source oscilloscope firmware for FNIRSI DSO152 (v0.3).  See README_firmware.md. */
#include "hw.h"
#include "lcd.h"
#include "afe.h"
#include "dsp.h"
#include "ui.h"
#include "buttons.h"
#include "battery.h"
#include "flashcal.h"

#define VERSION "v0.11"

static const uint32_t gen_freqs[] = { 1, 2, 5, 10, 20, 50, 100, 200, 500, 1000, 2000, 5000, 10000, 20000, 50000, 100000 };
#define GEN_NFREQ ((int)(sizeof gen_freqs / sizeof gen_freqs[0]))
#define GEN_1K_INDEX 9

static uint32_t capw[1536];                 /* DMA target: up to 3072 samples (fast sampling) */
#define cap ((uint16_t *)capw)
static uint16_t show[N_SAMPLES_MAX];        /* last complete frame (what is displayed) */
static int show_n, have_frame, cap_n;
static uint32_t frame_start_q8;
static cal_t cal;
static ui_state_t ui;
static dsp_stats_t st;
static int capturing, roll_wrapped, fast_bad;
static uint32_t roll_next, bat_next, cap_start_ms;

static void apply_settings(void);
static int cal_loaded;                      /* 1 = valid settings were found in flash at start-up */

/* ------------------------------------------------------------------ settings (kept in flash) */
static int clampi(int v, int lo, int hi) { return v < lo ? lo : (v > hi ? hi : v); }

static void ui_from_cal(void)
{
    const int16_t *u = cal.user;
    ui.range = clampi(u[U_RANGE], 0, AFE_NRANGES - 1);
    ui.tb = clampi(u[U_TB], 0, TB_COUNT - 1);
    ui.cpl = clampi(u[U_CPL], 0, 1);                  /* DC / AC */
    ui.rising = u[U_RISING] ? 1 : 0;
    ui.tmode = clampi(u[U_TMODE], 0, 2);
    ui.view = clampi(u[U_VIEW], 0, 1);
    ui.vpos = clampi(u[U_VPOS], -(PLOT_H / 2 - 4), PLOT_H / 2 - 4);
    ui.tlevel = clampi(u[U_TLEVEL], -2000, 2000);
    ui.hpos = clampi(u[U_HPOS], 0, PLOT_W - 5);
    ui.gen_on = u[U_GEN_ON] ? 1 : 0;
    ui.gen_fi = clampi(u[U_GEN_FI], 0, GEN_NFREQ - 1);
    ui.gen_duty = clampi(u[U_GEN_DUTY], 0, 100);
    ui.gen_hz = (int)gen_freqs[ui.gen_fi];
    ui.sinc = (u[U_SPARE1] == 1);
    ui.turbo = (u[U_SPARE2] == 1); afe_set_turbo(ui.turbo);
    ui.probe = (u[U_PROBE] == 10 || u[U_PROBE] == 100) ? u[U_PROBE] : 1;
    ui.hold = 0; ui.target = TG_TIME; ui.roll = 0;
}

static void pack_user(int16_t *u)
{
    u[U_RANGE] = (int16_t)ui.range; u[U_TB] = (int16_t)ui.tb; u[U_CPL] = (int16_t)ui.cpl; u[U_RISING] = (int16_t)ui.rising;
    u[U_TMODE] = (int16_t)ui.tmode; u[U_VIEW] = (int16_t)ui.view; u[U_VPOS] = (int16_t)ui.vpos; u[U_TLEVEL] = (int16_t)ui.tlevel;
    u[U_HPOS] = (int16_t)ui.hpos; u[U_GEN_ON] = (int16_t)ui.gen_on; u[U_GEN_FI] = (int16_t)ui.gen_fi; u[U_GEN_DUTY] = (int16_t)ui.gen_duty;
    u[U_BRIGHT] = 100; u[U_PROBE] = (int16_t)ui.probe;          /* U_BRIGHT is unused (kept for the flash layout) */ u[U_SPARE1] = (int16_t)ui.sinc; u[U_SPARE2] = (int16_t)ui.turbo;
}

/* Settings are written to flash only at power-off and before entering the bootloader (and right after calibration / factory reset). */
static void settings_flush(void)
{
    int16_t cur[U_COUNT]; int i, diff = 0;
    pack_user(cur);
    for (i = 0; i < U_COUNT; i++) if (cur[i] != cal.user[i]) diff = 1;
    if (diff) { for (i = 0; i < U_COUNT; i++) cal.user[i] = cur[i]; cal_save(&cal); }
}

/* ------------------------------------------------------------------ helpers */
static uint32_t klabel_q8(int range)        /* ADC counts per *labelled* division << 8 (probe does not change the signal at the input) */
{
    return (uint32_t)((uint64_t)cal.k_q8 * afe_ranges[range].label_mv * 10u / afe_ranges[range].phys_x10);
}

static uint32_t phys_probe_x10(void) { return afe_ranges[ui.range].phys_x10 * (uint32_t)ui.probe; }

static int px_to_counts(int px) { return (int)(((int64_t)px * klabel_q8(ui.range)) / (256 * PX_DIV)); }

static void gen_apply(void) { ui.gen_hz = (int)gen_freqs[ui.gen_fi]; afe_gen_set(gen_freqs[ui.gen_fi], ui.gen_duty, ui.gen_on); }

static void flush_buttons(void)
{
    int b;
    for (b = 0; b < B_COUNT; b++) { btn_pressed(b); btn_short(b); btn_long(b); }
}

static void battery_update(void)           /* only call while no capture is running (shared ADC) */
{
    uint32_t mv = battery_filter_mv(battery_mv_from_raw(adc_read_avg(7, 32), 3300));   /* PA7, divider 10k+10k (verified) */
    ui.bat_mv = (int)mv;
    ui.bat_pct = battery_display_percent(battery_percent_from_mv(mv));
}

/* ------------------------------------------------------------------ acquisition */
static void start_capture_tb(int tb)
{
    cap_start_ms = g_ms;
    if (afe_tb_fast(tb)) { cap_n = 2048; adc_capture_start_fast(capw, 1024); }
    else {
        int roll = (tb >= TB_ROLL_FROM);
        cap_n = roll ? 1024 : afe_tb_nsamples(tb);
        adc_capture_start(tb, cap, cap_n, roll);
    }
    capturing = 1;
}

static void start_capture(void)
{
    ui.roll = (ui.tb >= TB_ROLL_FROM);
    start_capture_tb(ui.tb);
    roll_wrapped = 0; roll_next = g_ms + 50;
}

static void stop_capture(void) { if (capturing) { adc_capture_stop(); capturing = 0; } }

static int capture_blocking(int tb, uint32_t timeout_ms)
{
    uint32_t t0 = g_ms; int ok = 0;
    start_capture_tb(tb);
    while ((uint32_t)(g_ms - t0) < timeout_ms) if (adc_capture_done()) { ok = 1; break; }
    stop_capture();
    return ok;
}

static void fast_fallback(void)             /* dual ADC mode failed: use timer sampling for 10/20 us from now on */
{
    stop_capture();
    afe_fast_disable();
    ui_message("FAST MODE OFF", "dual ADC gave no data", "using 800 kS/s");
    delay_ms(1500);
    ui_init();
    apply_settings();
}

static void copy_frame(void)                 /* DMA buffer -> display buffer (fast mode: unpack two samples per word) */
{
    int k;
    if (afe_tb_fast(ui.tb)) {
        {   /* ADC1 and ADC2 have different offsets: equalise the mean of the odd samples (ADC2) to the even ones (ADC1), smoothed over frames */
            static int32_t off_q8; static int off_init; int32_t se = 0, so = 0, d_q8, v;
            for (k = 0; k < 1024; k++) { se += (int32_t)(capw[k] & 0xFFFu); so += (int32_t)((capw[k] >> 16) & 0xFFFu); }
            d_q8 = (so - se) / 4;                                           /* mean difference << 8 (sum / 1024 * 256) */
            if (!off_init) { off_q8 = d_q8; off_init = 1; } else off_q8 += (d_q8 - off_q8) / 8;
            for (k = 0; k < 1024; k++) {
                show[2 * k] = (uint16_t)(capw[k] & 0xFFFu);
                v = (int32_t)((capw[k] >> 16) & 0xFFFu) - ((off_q8 + (off_q8 >= 0 ? 128 : -128)) / 256);
                show[2 * k + 1] = (uint16_t)(v < 0 ? 0 : (v > 4095 ? 4095 : v));
            }
        }
        show_n = 2048;
        { int zeros = 0; for (k = 0; k < 1024; k++) if (!(capw[k] >> 16)) zeros++;
          if (zeros > 900) fast_bad = 1; }                              /* ADC2 delivered nothing */
    } else {
        for (k = 0; k < cap_n; k++) show[k] = cap[k];
        show_n = cap_n;
    }
}

static void render(void)
{
    int zero = cal.zero[ui.range];
    uint32_t kl = klabel_q8(ui.range);
    if (ui.view != 1) {
        ui_plot(show, show_n, frame_start_q8, afe_tb_spd_q8(ui.tb), zero, kl, ui.vpos,
                ui.roll ? -1 : ui.hpos, ui.target == TG_HPOS ? C_WHITE : C_ORANGE, ui.sinc);
        ui_markers(&ui, zero, kl);
    }
    ui_status(&ui);
    ui_meas(&ui, &st, zero, cal.k_q8, phys_probe_x10());
}

static int process_oneshot(void)            /* returns 1 if a frame was displayed */
{
    uint64_t ts = afe_tb_ts_ns(ui.tb);
    uint32_t spd = afe_tb_spd_q8(ui.tb);
    int zero = cal.zero[ui.range], level, hyst, idx, need, pre, found;
    copy_frame();
    dsp_analyze(show, show_n, ts, zero, &st);
    hyst = (st.vmax - st.vmin) / 16; if (hyst < 3) hyst = 3;
    level = zero + ui.tlevel;
    need = (int)(((uint64_t)PLOT_W * spd) / (30u * 256u)) + 2;
    pre = (int)(((uint64_t)ui.hpos * spd) / (30u * 256u));
    idx = dsp_find_trigger(show, show_n, pre > 1 ? pre : 1, show_n - 1 - need + pre, level, hyst, ui.rising);
    found = (idx >= 0);
    if (found) {                                                /* sub-sample trigger position (linear interpolation of the level crossing) removes the 1-sample jitter */
        int p = show[idx - 1], c = show[idx], den = ui.rising ? (c - p) : (p - c), num = ui.rising ? (level - p) : (p - level);
        int fr = (den > 0) ? (num * 256) / den : 256;
        int32_t s = (int32_t)(idx - 1 - pre) * 256 + (fr < 0 ? 0 : (fr > 256 ? 256 : fr));
        frame_start_q8 = s < 0 ? 0u : (uint32_t)s;
    }
    else if (ui.tmode == TM_AUTO) frame_start_q8 = 0;          /* AUTO: free-running display */
    else return 0;                                              /* NORM / SINGLE: keep waiting */
    have_frame = 1;
    render();
    if (ui.tmode == TM_SINGLE && found) { ui.hold = 1; ui_status(&ui); }
    return 1;
}

static void roll_update(void)
{
    uint32_t spd = afe_tb_spd_q8(ui.tb);
    int pos = adc_capture_pos(), need = (int)(((uint64_t)PLOT_W * spd) / (30u * 256u)) + 2, k;
    if (adc_capture_wrapped()) roll_wrapped = 1;
    if (pos <= 0 && !roll_wrapped) return;
    for (k = 0; k < need; k++) {
        int i = pos - need + k;
        if (i < 0) i = roll_wrapped ? i + cap_n : 0;
        show[k] = cap[i];
    }
    show_n = need; frame_start_q8 = 0;
    dsp_analyze(show, show_n, afe_tb_ts_ns(ui.tb), cal.zero[ui.range], &st);
    have_frame = 1;
    render();
}

static void apply_settings(void)
{
    stop_capture();
    afe_set(ui.range, ui.cpl);
    ui.hold = 0;
    ui.roll = (ui.tb >= TB_ROLL_FROM);
    have_frame = 0;
    ui_status(&ui);
    start_capture();
}

/* ------------------------------------------------------------------ autoset */
static uint32_t cap_wait_ms(int tb) { return (uint32_t)((uint64_t)afe_tb_nsamples(tb) * afe_tb_ts_ns(tb) / 1000000u) + 250u; }

/* Most sensitive range where the signal is not clipped and is at most 6 divisions peak to peak (statistics of that range stay in `st`). */
static int pick_range(int tb, int start)
{
    int r; uint64_t ts = afe_tb_ts_ns(tb);
    for (r = start; r < AFE_NRANGES; r++) {
        afe_set(r, ui.cpl);
        if (!capture_blocking(tb, cap_wait_ms(tb))) continue;
        dsp_analyze(cap, cap_n, ts, cal.zero[r], &st);
        if (!st.clipped && (uint64_t)(st.vmax - st.vmin) * 256u <= 6ull * klabel_q8(r)) return r;
    }
    return AFE_NRANGES - 1;
}

static void autoset(void)
{
    static const int probe_tb[4] = { 3, 6, 9, 10 };      /* 100 us, 1 ms, 10 ms, 20 ms per division */
    int r, i, tb = 6, mid; uint32_t period = 0;
    stop_capture();
    ui_message("AUTOSET", "searching...", "");
    ui.tmode = TM_AUTO;
    r = pick_range(3, 0);                                /* 1: range from a quick look at 100 us/div */
    if (st.vmax - st.vmin < 12) {                        /* no signal: sensible defaults */
        ui.range = 6; ui.tb = 6; ui.tlevel = 0; ui.vpos = 0;
        ui_init(); apply_settings();
        return;
    }
    for (i = 0; i < 4 && !period; i++) {                 /* 2: find the signal period */
        afe_set(r, ui.cpl);
        if (capture_blocking(probe_tb[i], cap_wait_ms(probe_tb[i]))) {
            dsp_analyze(cap, cap_n, afe_tb_ts_ns(probe_tb[i]), cal.zero[r], &st);
            if (st.have_freq && st.period_us) period = st.period_us;
        }
    }
    if (period) {                                        /* 3: about three periods on the screen */
        for (i = 0; i < TB_ROLL_FROM - 1; i++) if (afe_tb_tdiv_us(i) * 3u >= period) break;
        tb = i;
    }
    r = pick_range(tb, r > 0 ? r - 1 : 0);               /* 4: final range, measured over whole periods */
    mid = (st.vmax + st.vmin) / 2;
    ui.range = r; ui.tb = tb;
    ui.tlevel = mid - cal.zero[r];                       /* trigger in the middle of the signal */
    ui.vpos = clampi(-(int)(((int64_t)(mid - cal.zero[r]) * PX_DIV * 256) / (int64_t)klabel_q8(r)), -(PLOT_H / 2 - 4), PLOT_H / 2 - 4);   /* signal centred on the screen */
    ui_init();
    apply_settings();
}

/* ------------------------------------------------------------------ menus */
static int wait_confirm(void)               /* short OK (or RUN) = yes, long OK = cancel */
{
    flush_buttons();
    for (;;) {
        if (btn_short(B_OK) || btn_short(B_RUN)) return 1;
        if (btn_long(B_OK)) return 0;
    }
}

static void zero_cal(void)
{
    int r;
    ui_message("ZERO CALIBRATION", "input is grounded inside", "OK=start  long OK=cancel");
    if (wait_confirm()) {
        ui_message("ZERO CALIBRATION", "measuring...", "");
        for (r = 0; r < AFE_NRANGES; r++) { afe_set(r, CPL_GND); delay_ms(30); cal.zero[r] = adc_avg_input(256); }
        afe_set(ui.range, ui.cpl);
        ui_message("ZERO CALIBRATION", cal_save(&cal) ? "saved to flash" : "flash write FAILED", "");
        delay_ms(1200);
    }
}

static void gain_cal(void)
{
    ui_message("GAIN CALIBRATION", "probe on the 1 kHz output", "OK=start  long OK=cancel");
    if (wait_confirm()) {
        afe_gen_set(1000, 50, 1);                       /* 3.3 V p-p, 1 kHz */
        afe_set(6, CPL_DC);
        delay_ms(50);
        if (capture_blocking(6, 800)) {
            dsp_analyze(cap, cap_n, afe_tb_ts_ns(6), cal.zero[6], &st);
            if (st.vmax - st.vmin > 300 && st.vmax - st.vmin < 4000) {
                cal.k_q8 = (uint32_t)(st.vmax - st.vmin) * 2560u / 33u;   /* 3.3 V p-p at 1 V/div = 3.3 div */
                ui_message("GAIN CALIBRATION", cal_save(&cal) ? "saved to flash" : "flash write FAILED", "");
            } else ui_message("GAIN CALIBRATION", "no valid signal", "probe on the output?");
        } else ui_message("GAIN CALIBRATION", "capture timeout", "");
        gen_apply();                                    /* generator returns to the user's setting */
        afe_set(ui.range, ui.cpl);
        delay_ms(1500);
    }
}

/* Menu navigation (wraps around): rocker LEFT = move down, rocker RIGHT = move up; UP/DOWN keys do the same. Returns 1 if the selection moved. */
static int menu_nav(int *sel, int n)
{
    int d = 0;
    if (btn_pressed(B_LEFT) || btn_pressed(B_DOWN)) d = 1;
    if (btn_pressed(B_RIGHT) || btn_pressed(B_UP)) d = -1;
    if (!d) return 0;
    *sel = (*sel + d + n) % n;
    return 1;
}

static void menu_gen(void)
{
    int redraw = 1; char t[16], b[24];
    flush_buttons();
    for (;;) {
        if (redraw) {
            ui_init(); ui_title("SIGNAL GENERATOR");
            fmt_freq(t, gen_freqs[ui.gen_fi] * 1000u); ui_row(0, "Frequency", t, 0);
            { char n[8]; int k = 0; fmt_uint(n, (uint32_t)ui.gen_duty); while (n[k]) { b[k] = n[k]; k++; } b[k++] = '%'; b[k] = 0; }
            ui_row(1, "Duty", b, 0);
            ui_row(2, "Output", ui.gen_on ? "ON" : "OFF", 0);
            lcd_str16(8, 112, "L/R: frequency   UP/DN: duty", C_DIM, C_BLACK);
            lcd_str16(8, 132, "RUN: output on/off", C_DIM, C_BLACK);
            lcd_str16(8, 152, "OK: back", C_DIM, C_BLACK);
            redraw = 0;
        }
        if (btn_pressed(B_RIGHT)) { if (ui.gen_fi < GEN_NFREQ - 1) ui.gen_fi++; gen_apply(); redraw = 1; }
        if (btn_pressed(B_LEFT))  { if (ui.gen_fi > 0) ui.gen_fi--; gen_apply(); redraw = 1; }
        if (btn_pressed(B_UP))    { if (ui.gen_duty < 100) ui.gen_duty += 5; gen_apply(); redraw = 1; }
        if (btn_pressed(B_DOWN))  { if (ui.gen_duty > 0) ui.gen_duty -= 5; gen_apply(); redraw = 1; }
        if (btn_short(B_RUN))     { ui.gen_on = !ui.gen_on; gen_apply(); redraw = 1; }
        if (btn_short(B_OK) || btn_long(B_OK)) break;
    }
}

/* Go to the USB bootloader (flash 0x08000000) in update mode. A direct jump is used instead of a reset: a reset releases the
   power latch (PC10) for a moment and the instrument could switch itself off. The magic word in the last 16 bytes of RAM
   (outside the linker's RAM region) makes the bootloader show the "DSO152 BOOT" USB disk. */
static void enter_bootloader(void)
{
    uint32_t sp = *(volatile uint32_t *)0x08000000u, rs = *(volatile uint32_t *)0x08000004u, t;
    settings_flush();
    stop_capture();
    __asm volatile("cpsid i");
    STK_CTRL = 0;
    *(volatile uint32_t *)0xE000E180u = 0xFFFFFFFFu; *(volatile uint32_t *)0xE000E184u = 0xFFFFFFFFu;   /* NVIC: disable + clear all */
    *(volatile uint32_t *)0xE000E280u = 0xFFFFFFFFu; *(volatile uint32_t *)0xE000E284u = 0xFFFFFFFFu;
    *(volatile uint32_t *)0x40020008u = 0;                      /* DMA1 channel 1 off */
    RCC->APB2RSTR = 0x5E0Du;  RCC->APB2RSTR = 0;                /* AFIO, GPIOA/B, ADC1/2, TIM1, SPI1, USART1 (GPIOC is kept: power latch + backlight) */
    RCC->APB1RSTR = 0x00FFFFFFu; RCC->APB1RSTR = 0;             /* TIM2..7, USART/I2C/SPI, USB, CAN ... */
    RCC->CR |= 1u;                                              /* back to HSI, PLL off: the bootloader sets its own clocks */
    for (t = 0; t < 0x20000 && !(RCC->CR & 2u); t++) { }
    RCC->CFGR = 0;
    for (t = 0; t < 0x20000 && (RCC->CFGR & 0xCu); t++) { }
    RCC->CR &= ~(1u << 24);
    *(volatile uint32_t *)0x20004FF0u = 0xB007DF11u;       /* tell the bootloader to stay in update mode */
    SCB_VTOR = 0x08000000u;
    __asm volatile("msr msp, %0\n\tbx %1" :: "r"(sp), "r"(rs));
    for (;;) { }
}

static void menu_settings(void)
{
    int sel = 0, redraw = 1;
    flush_buttons();
    for (;;) {
        if (redraw) {
            ui_init(); ui_title("SETTINGS");
            ui_row(0, "Zero calibration", "", sel == 0);
            ui_row(1, "Gain calibration", "", sel == 1);
            ui_row(2, "Factory defaults", "", sel == 2);
            ui_row(3, "USB update (bootloader)", "", sel == 3);
            ui_row(4, "About", "", sel == 4);
            redraw = 0;
        }
        if (menu_nav(&sel, 5)) redraw = 1;
        if (btn_short(B_OK)) {                                  /* short OK = select */
            if (sel == 0) zero_cal();
            else if (sel == 1) gain_cal();
            else if (sel == 2) {
                ui_message("FACTORY DEFAULTS", "reset settings?", "OK=yes  long OK=no");
                if (wait_confirm()) { cal_defaults_user(&cal); ui_from_cal(); gen_apply(); cal_save(&cal); }
            } else if (sel == 3) {
                ui_message("USB UPDATE", "restart to bootloader?", "OK=yes  long OK=no");
                if (wait_confirm()) enter_bootloader();
            } else {
                ui_message("DSO152 open firmware", VERSION, "OK = back"); wait_confirm();
            }
            redraw = 1; flush_buttons();
        }
        if (btn_long(B_OK)) break;                              /* long OK = exit */
    }
}

static void menu_main(void)
{
    int sel = 0, redraw = 1; char t[12];
    stop_capture();
    flush_buttons();
    for (;;) {
        if (redraw) {
            ui_init(); ui_title("MENU");
            ui_row(0, "Oscilloscope", "", sel == 0);
            t[0] = 'x'; fmt_uint(t + 1, (uint32_t)ui.probe); ui_row(1, "Probe", t, sel == 1);       /* 1x / 10x / 100x */
            ui_row(2, "Signal generator", "", sel == 2);
            { char g[24]; char *p = g; fmt_freq(p, (uint32_t)gen_freqs[ui.gen_fi] * 1000u); while (*p) p++;
                *p++ = ' '; fmt_uint(p, (uint32_t)ui.gen_duty); while (*p) p++; *p++ = '%'; *p = 0;
                ui_row2(3, "Generator output", g, ui.gen_on ? "ON" : "OFF", sel == 3); }
            ui_row(4, "CAL signal 1kHz 50%", "", sel == 4);
            ui_row(5, "Sin(x)/x", ui.sinc ? "ON" : "OFF", sel == 5);
            ui_row(6, "Fast sampling 10/20us", ui.turbo ? "ON" : "OFF", sel == 6);
            ui_row(7, "Settings", "", sel == 7);
            redraw = 0;
        }
        if (menu_nav(&sel, 8)) redraw = 1;
        if (btn_short(B_OK)) {                                  /* short OK = select / change the value */
            if (sel == 0) break;
            else if (sel == 1) ui.probe = (ui.probe == 1) ? 10 : (ui.probe == 10 ? 100 : 1);
            else if (sel == 2) menu_gen();
            else if (sel == 3) { ui.gen_on = !ui.gen_on; gen_apply(); }                                      /* quick output on/off */
            else if (sel == 4) { ui.gen_fi = GEN_1K_INDEX; ui.gen_duty = 50; ui.gen_on = 1; gen_apply(); }   /* quick calibration signal */
            else if (sel == 5) ui.sinc = !ui.sinc;                                                           /* sin(x)/x on/off */
            else if (sel == 6) { ui.turbo = !ui.turbo; afe_set_turbo(ui.turbo); }                            /* fast sampling on/off */
            else menu_settings();
            redraw = 1; flush_buttons();
        }
        if (btn_long(B_OK)) break;                              /* long OK = exit to the oscilloscope */
    }
    ui_init();
    apply_settings();
}

/* ------------------------------------------------------------------ main */
int main(void)
{
    power_hold();                                   /* first thing: keep the board powered */
    buttons_init();                                 /* from now on the SysTick interrupt samples the buttons */
    cal_loaded = cal_load(&cal);
    ui_from_cal();
    lcd_init();
    afe_init();
    gen_apply();
    ui_init();
    lcd_str16(72, 100, "DSO152 open firmware", C_TRACE, C_BLACK);
    lcd_str16(136, 120, VERSION, C_WHITE, C_BLACK);
    delay_ms(1000);
    ui_init();

    { uint32_t t = g_ms; while (!(GPIOC->IDR & PIN(PC_BTN_POWER)) && (uint32_t)(g_ms - t) < 3000) { } }   /* wait for power button release */
    delay_ms(50);
    flush_buttons();

    battery_update();
    bat_next = g_ms + 2000;
    apply_settings();

    for (;;) {
        int changed = 0, redraw = 0, marker = 0;

        if (btn_pressed(B_UP))    { if (ui.range < AFE_NRANGES - 1) { ui.range++; changed = 1; } }
        if (btn_pressed(B_DOWN))  { if (ui.range > 0) { ui.range--; changed = 1; } }
        if (btn_pressed(B_RIGHT) || btn_pressed(B_LEFT)) {
            int d = btn_down(B_RIGHT) ? 1 : -1;
            switch (ui.target) {
            case TG_TIME: if (ui.tb + d >= 0 && ui.tb + d < TB_COUNT) { ui.tb += d; changed = 1; } break;
            case TG_VPOS: ui.vpos = clampi(ui.vpos + 2 * d, -(PLOT_H / 2 - 4), PLOT_H / 2 - 4); redraw = 1; break;
            case TG_TRIG: ui.tlevel = clampi(ui.tlevel + px_to_counts(2) * d, -2000, 2000); marker = 1; break;
            default:      ui.hpos = clampi(ui.hpos + 5 * d, 0, PLOT_W - 5); redraw = 1; break;
            }
        }
        if (btn_short(B_MODE))    { ui.tmode = (ui.tmode + 1) % 3; changed = 1; }
        if (btn_long(B_MODE))     { ui.rising = !ui.rising; changed = 1; }
        if (btn_short(B_RUN))     {
            ui.hold = !ui.hold;
            if (ui.hold) { stop_capture(); ui_status(&ui); }
            else { stop_capture(); start_capture(); ui_status(&ui); }
        }
        if (btn_long(B_RUN))      { ui.view = (ui.view + 1) % 2; ui_init(); if (have_frame) render(); else ui_status(&ui); }
        if (btn_short(B_AUTO))    { autoset(); }
        if (btn_long(B_AUTO))     { ui.cpl = (ui.cpl + 1) % 2; changed = 1; }       /* DC <-> AC */
        if (btn_short(B_OK))      {                                     /* 50 %: trigger level to the middle of the signal */
            if (have_frame) ui.tlevel = ((st.vmax + st.vmin) / 2) - cal.zero[ui.range];
            ui.vpos = 0; redraw = 1;
        }
        if (btn_long(B_OK))       { menu_main(); }
        if (btn_short(B_POWER))   { ui.target = (ui.target + 1) % TG_COUNT; ui_status(&ui); redraw = 1; }
        if (btn_long(B_POWER))    {
            stop_capture(); settings_flush(); lcd_backlight(0); power_off();
            for (;;) { }                                                /* board powers down when the button is released */
        }
        (void)btn_pressed(B_POWER); (void)btn_pressed(B_AUTO); (void)btn_pressed(B_OK); (void)btn_pressed(B_MODE); (void)btn_pressed(B_RUN);

        if (changed) { apply_settings(); }
        else if (redraw && have_frame) { render(); }
        else if (marker && have_frame) { ui_markers(&ui, cal.zero[ui.range], klabel_q8(ui.range)); }

        if (capturing) {
            if (!ui.roll) {
                if (afe_tb_fast(ui.tb) && (uint32_t)(g_ms - cap_start_ms) > 40u) { fast_fallback(); continue; }   /* no data in 40 ms */
                if (adc_capture_done()) {
                    stop_capture();
                    process_oneshot();
                    if (fast_bad) { fast_bad = 0; fast_fallback(); continue; }
                    if ((int32_t)(g_ms - bat_next) >= 0) { battery_update(); bat_next = g_ms + 2000; }
                    if (!ui.hold) start_capture();
                }
            } else if ((int32_t)(g_ms - roll_next) >= 0) {
                roll_next = g_ms + 50;
                roll_update();
            }
        }
        if (ui.roll && (int32_t)(g_ms - bat_next) >= 0 && !ui.hold) {      /* roll mode: brief pause for the battery reading */
            stop_capture(); battery_update(); bat_next = g_ms + 30000u; start_capture();
        }
    }
}
