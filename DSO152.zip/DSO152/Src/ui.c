/* Landscape 320x240 user interface; text uses the stock 8x16 character cell.
   View 0: waveform (300x160, 8 divisions of 20 px) + nine measurements, 3 columns.
   View 1: full-screen table of all measurements.  View 2: waveform only. */
#include "hw.h"
#include "lcd.h"
#include "ui.h"
#include "afe.h"


static uint8_t rowt[PLOT_H];         /* bit0: grid line row, bit1: tick row, bit2: centre row */
static uint8_t ycol[PLOT_W];

/* Only changed text is redrawn: this removes the flicker of the status line and the measurements. */
#define NSLOT 14
static char slot_txt[NSLOT][28];
static uint16_t slot_col[NSLOT];
static int status_sig[16], status_valid;
static int mk_yg = -1000, mk_yt = -1000, mk_tg = -1, mk_roll = -1;

static char *cat(char *o, const char *s) { while (*s) *o++ = *s++; return o; }
static int slen(const char *s) { int n = 0; while (s[n]) n++; return n; }

static int tok(int x, int y, const char *s, uint16_t fg)
{
    lcd_str16(x, y, s, fg, C_BLACK);
    return x + slen(s) * 8;
}

/* label (dim) + value (coloured), padded with blanks to `width` characters */
static void item(int slot, int x, int y, int width, const char *label, const char *val, uint16_t vc)
{
    char pad[32], key[28]; int used = slen(label) + slen(val), i;
    { char *k = key; k = cat(k, label); k = cat(k, val); *k = 0; }
    for (i = 0; i < 27 && key[i] == slot_txt[slot][i] && key[i]; i++) { }
    if (key[i] == 0 && slot_txt[slot][i] == 0 && slot_col[slot] == vc) return;     /* unchanged */
    for (i = 0; i < 27 && key[i]; i++) slot_txt[slot][i] = key[i];
    slot_txt[slot][i] = 0; slot_col[slot] = vc;
    x = tok(x, y, label, C_DIM);
    x = tok(x, y, val, vc);
    for (i = 0; i < width - used && i < 30; i++) pad[i] = ' ';
    pad[i] = 0;
    if (i > 0) lcd_str16(x, y, pad, C_BLACK, C_BLACK);
}

void ui_init(void)
{
    int y;
    int s;
    for (y = 0; y < PLOT_H; y++) rowt[y] = (uint8_t)(((y % PX_DIV) == 0) | (((y % 5) == 0) << 1) | ((y == PLOT_H / 2) << 2));
    for (s = 0; s < NSLOT; s++) { slot_txt[s][0] = 0; slot_col[s] = 0; }
    status_valid = 0; mk_yg = mk_yt = -1000; mk_tg = mk_roll = -1;
    lcd_fill(0, 0, LCD_W, LCD_H, C_BLACK);
}

void ui_plot(const uint16_t *s, int n, uint32_t start_q8, uint32_t spd_q8, int zero, uint32_t klabel_q8, int vpos, int hpos_marker, uint16_t hpos_color, int sinc)
{
    int x, y, prev;
    uint32_t step_q8 = spd_q8 / 30u;
    int use_sinc = sinc && step_q8 < 256u;                        /* only useful with fewer than 1 sample per pixel */
    for (x = 0; x < PLOT_W; x++) {
        uint32_t pos = start_q8 + (uint32_t)(((uint64_t)x * spd_q8) / 30u);
        ycol[x] = (uint8_t)dsp_y(use_sinc ? dsp_interp_sinc(s, n, pos) : dsp_interp(s, n, pos), zero, klabel_q8, vpos);
    }
    prev = ycol[0];
    for (x = 0; x < PLOT_W; x++) {
        int cur = ycol[x], lo = prev < cur ? prev : cur, hi = prev < cur ? cur : prev;
        int colv = (x % 30) == 0 || x == PLOT_W - 1, colh = (x % 5) == 0, colc = (x == PLOT_W / 2);
        lcd_window(PLOT_X + x, PLOT_Y, PLOT_X + x, PLOT_Y + PLOT_H - 1);
        for (y = 0; y < PLOT_H; y++) {
            uint16_t c = C_BLACK; uint8_t rt = rowt[y];
            if ((colv && (rt & 2)) || (colh && (rt & 1))) c = C_GRID;
            if (colc || (rt & 4)) c = C_AXIS;
            if (y >= lo && y <= hi) c = C_TRACE;
            if (hpos_marker >= 0 && y < 5 && x >= hpos_marker - (4 - y) && x <= hpos_marker + (4 - y)) c = hpos_color;   /* trigger position */
            lcd_put(c);
        }
        prev = cur;
    }
}

void ui_markers(const ui_state_t *st, int zero, uint32_t klabel_q8)
{
    int yg = PLOT_H / 2 - st->vpos, yt = dsp_y(zero + st->tlevel, zero, klabel_q8, st->vpos);
    if (yg < 0) yg = 0;
    if (yg > PLOT_H - 1) yg = PLOT_H - 1;
    if (yg != mk_yg) {
        lcd_fill(0, PLOT_Y, PLOT_X, PLOT_H, C_BLACK);
        lcd_str(1, PLOT_Y + yg - 4, ">", C_CYAN, C_BLACK, 1);                              /* zero level */
        mk_yg = yg;
    }
    if (yt != mk_yt || st->target != mk_tg || st->roll != mk_roll) {
        lcd_fill(PLOT_X + PLOT_W, PLOT_Y, LCD_W - PLOT_X - PLOT_W, PLOT_H, C_BLACK);
        if (!st->roll) lcd_str(PLOT_X + PLOT_W + 2, PLOT_Y + yt - 4, "<", st->target == TG_TRIG ? C_WHITE : C_ORANGE, C_BLACK, 1);   /* trigger level */
        mk_yt = yt; mk_tg = st->target; mk_roll = st->roll;
    }
}

void ui_status(const ui_state_t *st)
{
    static const char *const cpl[3] = { "DC", "AC", "GND" };
    static const char *const tm[3] = { "AUTO", "NORM", "SNGL" };
    static const char *const tg[TG_COUNT] = { "TIME", "VPOS", "TRIG", "HPOS" };
    int sig[16] = { st->range, st->tb, st->cpl, st->tmode, st->roll, st->rising, st->hold, st->target, st->gen_on, st->bat_pct, st->probe, st->gen_on ? st->gen_hz : -1 };
    int x = 2, i, same = status_valid; char t[12], *p = t, vd[12]; int v = st->bat_pct;
    for (i = 0; i < 12; i++) if (sig[i] != status_sig[i]) same = 0;
    if (same) return;                                    /* nothing visible changed: no redraw, no flicker */
    for (i = 0; i < 12; i++) status_sig[i] = sig[i];
    status_valid = 1;
    fmt_vdiv(vd, (uint32_t)afe_ranges[st->range].label_mv * (uint32_t)st->probe);
    lcd_fill(0, 0, LCD_W, 19, C_BLACK);
    x = tok(x, 1, vd, C_TRACE);                          x += 8;
    x = tok(x, 1, tb_names[st->tb], C_CYAN);             x += 8;
    x = tok(x, 1, cpl[st->cpl], C_WHITE);                x += 8;
    x = tok(x, 1, st->roll ? "ROLL" : tm[st->tmode], C_LGREEN); x += 8;
    x = tok(x, 1, st->rising ? "/" : "\\", C_ORANGE);    x += 8;
    x = tok(x, 1, st->hold ? "STOP" : "RUN", st->hold ? C_RED : C_LGREEN); x += 8;
    x = tok(x, 1, tg[st->target], C_BLUE);
    if (v >= 100) { *p++ = '1'; *p++ = '0'; *p++ = '0'; }
    else if (v >= 10) { *p++ = (char)('0' + v / 10); *p++ = (char)('0' + v % 10); }
    else *p++ = (char)('0' + v);
    *p++ = '%'; *p = 0;
    if (st->gen_on) {                                    /* generator running: "G" + frequency, e.g. G50 (Hz), G1k, G100k (kHz) */
        char g[10], *q = g; uint32_t hz = (uint32_t)st->gen_hz, n = hz >= 1000u ? hz / 1000u : hz; char d[6]; int k = 0;
        *q++ = 'G';
        do { d[k++] = (char)('0' + n % 10u); n /= 10u; } while (n);
        while (k) *q++ = d[--k];
        if (hz >= 1000u) *q++ = 'k';
        *q = 0;
        x += 8;
        if (x + slen(g) * 8 + 8 > LCD_W - 2 - slen(t) * 8) { g[1] = 0; }       /* no room: just "G" */
        x = tok(x, 1, g, C_MAG);
    }
    tok(LCD_W - 2 - slen(t) * 8, 1, t, st->bat_pct < 15 ? C_RED : C_WHITE);
}

void ui_meas(const ui_state_t *st, const dsp_stats_t *d, int zero, uint32_t k_q8, uint32_t phys_x10)
{
    char vpp[16], vmax[16], vmin[16], vavg[16], vrms[16], fr[16], cyc[16], wp[16], wn[16], dp[16], dn[16], bt[24];
    int32_t mx = dsp_counts_to_mv(d->vmax - zero, phys_x10, k_q8);
    int32_t mn = dsp_counts_to_mv(d->vmin - zero, phys_x10, k_q8);
    int32_t av = dsp_counts_to_mv((d->avg_x16 - zero * 16) / 16, phys_x10, k_q8);
    int32_t rm = dsp_counts_to_mv((int32_t)d->rms, phys_x10, k_q8);
    uint16_t vc = d->clipped ? C_RED : C_TRACE;
    fmt_volt(vpp, mx - mn); fmt_volt(vmax, mx); fmt_volt(vmin, mn); fmt_volt(vavg, av); fmt_volt(vrms, rm);
    if (d->have_freq) {
        fmt_freq(fr, d->freq_mhz); fmt_time(cyc, d->period_us);
        fmt_time(wp, d->wpos_us); fmt_time(wn, d->wneg_us);
        fmt_pct10(dp, d->duty_pos_x10); fmt_pct10(dn, d->duty_neg_x10);
    } else { fr[0] = cyc[0] = wp[0] = wn[0] = dp[0] = dn[0] = '-'; fr[1] = cyc[1] = wp[1] = wn[1] = dp[1] = dn[1] = 0; }
    { char *o = bt; char b[8]; fmt_volt(b, st->bat_mv); o = cat(o, b); o = cat(o, " "); fmt_uint(b, (uint32_t)st->bat_pct); o = cat(o, b); o = cat(o, "%"); *o = 0; }

    if (st->view == 0) {
        int y0 = PLOT_Y + PLOT_H + 2;                       /* 182: three rows of 16 px */
        item(0, 2,   y0,      13, "Vmax ", vmax, C_LGREEN); item(1, 108, y0,      13, "Vmin ", vmin, C_BLUE);   item(2, 214, y0,      13, "Vpp ",  vpp, vc);
        item(3, 2,   y0 + 17, 13, "Vave ", vavg, C_WHITE);  item(4, 108, y0 + 17, 13, "Vrms ", vrms, C_CYAN);   item(5, 214, y0 + 17, 13, "Fre ",  fr,  C_ORANGE);
        item(6, 2,   y0 + 34, 13, "Cyc ",  cyc,  C_ORANGE); item(7, 108, y0 + 34, 13, "+Dut ", dp,   C_MAG);    item(8, 214, y0 + 34, 13, "-Dut ", dn,  C_MAG);
    } else {
        int y = 22;
        item(0, 2, y, 38, "Vmax   ",  vmax, C_LGREEN); y += 17;
        item(1, 2, y, 38, "Vmin   ",  vmin, C_BLUE);   y += 17;
        item(2, 2, y, 38, "Vpp    ",  vpp,  vc);       y += 17;
        item(3, 2, y, 38, "Vave   ",  vavg, C_WHITE);  y += 17;
        item(4, 2, y, 38, "Vrms   ",  vrms, C_CYAN);   y += 17;
        item(5, 2, y, 38, "Fre    ",  fr,   C_ORANGE); y += 17;
        item(6, 2, y, 38, "Cyc    ",  cyc,  C_ORANGE); y += 17;
        item(7, 2, y, 38, "+Width ",  wp,   C_MAG);    y += 17;
        item(8, 2, y, 38, "-Width ",  wn,   C_MAG);    y += 17;
        item(9, 2, y, 38, "+Dut   ",  dp,   C_WHITE);  y += 17;
        item(10, 2, y, 38, "-Dut   ",  dn,   C_WHITE);  y += 17;
        item(11, 2, y, 38, "Batt   ",  bt,   st->bat_pct < 15 ? C_RED : C_LGREEN);
    }
}

/* Row with an extra coloured text (magenta) placed left of the right-aligned value. */
void ui_row2(int row, const char *label, const char *extra, const char *value, int selected)
{
    int y = 24 + row * 20; uint16_t bg = selected ? C_SEL : C_BLACK; int xv = LCD_W - 8 - slen(value) * 8;
    ui_row(row, label, value, selected);
    lcd_str16(xv - 16 - slen(extra) * 8, y, extra, C_MAG, bg);
}

void ui_message(const char *l1, const char *l2, const char *l3)
{
    lcd_fill(14, 70, 292, 100, C_BLACK);
    lcd_fill(14, 70, 292, 2, C_WHITE); lcd_fill(14, 168, 292, 2, C_WHITE);
    lcd_fill(14, 70, 2, 100, C_WHITE); lcd_fill(304, 70, 2, 100, C_WHITE);
    lcd_str16(24, 80, l1, C_TRACE, C_BLACK);
    lcd_str16(24, 108, l2, C_WHITE, C_BLACK);
    lcd_str16(24, 136, l3, C_CYAN, C_BLACK);
}

void ui_title(const char *t)
{
    lcd_fill(0, 0, LCD_W, 20, C_BLACK);
    lcd_str16(8, 2, t, C_TRACE, C_BLACK);
    lcd_fill(0, 19, LCD_W, 1, C_AXIS);
}

void ui_row(int row, const char *label, const char *value, int selected)
{
    int y = 24 + row * 20; uint16_t bg = selected ? C_SEL : C_BLACK;
    lcd_fill(0, y - 2, LCD_W, 20, bg);
    lcd_str16(8, y, label, C_WHITE, bg);
    if (value[0]) lcd_str16(LCD_W - 8 - slen(value) * 8, y, value, C_CYAN, bg);
}
