#include "hw.h"
#include "flashcal.h"
#include "dsp.h"

static uint32_t checksum(const cal_t *c)
{
    const uint16_t *p = (const uint16_t *)c; uint32_t s = 0x5A5Au; unsigned i;
    for (i = 0; i < (sizeof(cal_t) - 4) / 2; i++) s = (s << 1 | s >> 31) ^ p[i];
    return s;
}

void cal_defaults_user(cal_t *c)
{
    static const int16_t d[U_COUNT] = { 6, 6, 0, 1, 0, 0, 0, 0, 60, 0, 9, 50, 100, 1, 0, 0 };
    int i;
    for (i = 0; i < U_COUNT; i++) c->user[i] = d[i];
}

void cal_defaults(cal_t *c)
{
    int i;
    c->magic = CAL_MAGIC; c->pad = 0xFFFF; c->k_q8 = DEFAULT_K_Q8;
    for (i = 0; i < AFE_NRANGES; i++) c->zero[i] = DEFAULT_ZERO;
    cal_defaults_user(c);
    c->check = checksum(c);
}

int cal_load(cal_t *c)
{
    const cal_t *f = (const cal_t *)CAL_ADDR;
    if (f->magic == CAL_MAGIC && f->check == checksum(f)) { *c = *f; return 1; }
    cal_defaults(c);
    return 0;
}

static void fwait(void) { while (FLASH->SR & 1u) { } }

static uint32_t g_saves, g_fail;
static int g_last_ok = -1;
void cal_save_status(int *last_ok, uint32_t *saves, uint32_t *fails) { *last_ok = g_last_ok; *saves = g_saves; *fails = g_fail; }

/* One erase + program attempt of the settings page. Returns 1 when every halfword reads back correctly and the controller
   reported no error (SR: PGERR bit 2, WRPRTERR bit 4). */
static int try_save(const cal_t *c)
{
    const uint16_t *p = (const uint16_t *)c; unsigned i; int ok = 1;
    if (FLASH->CR & (1u << 7)) { FLASH->KEYR = 0x45670123u; FLASH->KEYR = 0xCDEF89ABu; }     /* unlock only when locked */
    if (FLASH->CR & (1u << 7)) return 0;
    fwait();
    FLASH->SR = 0x34u;                                       /* clear EOP, WRPRTERR, PGERR left over from earlier operations */
    FLASH->CR = (1u << 1); FLASH->AR = CAL_ADDR; FLASH->CR |= (1u << 6); fwait();   /* PER, STRT */
    FLASH->CR = 0;
    if (FLASH->SR & 0x14u) ok = 0;
    FLASH->SR = 0x34u;
    for (i = 0; i < sizeof(cal_t) / 2; i++) {
        FLASH->CR = 1u;                                      /* PG */
        *(IO uint16_t *)(CAL_ADDR + 2u * i) = p[i];
        fwait();
        FLASH->CR = 0;
    }
    if (FLASH->SR & 0x14u) ok = 0;
    FLASH->SR = 0x34u;
    FLASH->CR = (1u << 7);                                   /* LOCK */
    for (i = 0; i < sizeof(cal_t) / 2; i++) if (((const uint16_t *)CAL_ADDR)[i] != p[i]) ok = 0;
    return ok;
}

int cal_save(const cal_t *src)
{
    cal_t c = *src; int ok, tries;
    c.magic = CAL_MAGIC; c.check = checksum(&c);
    for (tries = 0; tries < 3; tries++) { ok = try_save(&c); if (ok) break; }   /* retry: a failed attempt re-erases the page */
    g_saves++; g_last_ok = ok; if (!ok) g_fail++;
    return ok;
}
