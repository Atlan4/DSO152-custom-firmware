/* Analog front end: 4051 range select, relay, AC/DC/GND, generator output, ADC + DMA capture.
   Range table from the stock firmware (function at 0x080050F4): ranges 0..4 relay off, mux 0..4;
   ranges 5..10 relay on, mux 0..5.  4051 address = PA6:PA5:PA4; mux channel 6 is tied to ground (GND coupling). */
#include "hw.h"
#include "afe.h"

#define PA3_DC_LEVEL 1   /* PA3 level for DC coupling (opto shorts the 47 nF cap). Swap if AC/DC appears reversed. */
#define FAST_ADC 0       /* 1 = 10 and 20 us/div use ADC1+ADC2 interleaved at 18 MHz (2.57 MS/s, like the stock firmware); 0 = timer mode only (default: the dual ADC mode delivered no ADC2 data on this device, and the stock firmware does not use it) */
#define TIM_CLK_HZ 72000000u
#define MIN_TICKS  90u   /* 1.25 us: shortest timer-triggered sample period (ADC 1.5 cycle sampling at 12 MHz = 1.17 us) */
#define FAST_TS_NS 389u  /* fast mode: 7 ADC cycles at 18 MHz = 389 ns between interleaved samples (2.57 MS/s) */

const afe_range_t afe_ranges[AFE_NRANGES] = {
    {0,0,  10,    125}, {0,1,  20,    250}, {0,2,  50,    500}, {0,3, 100,   1000}, {0,4, 200,   2000},
    {1,0, 500,   5000}, {1,1,1000,  10000}, {1,2,2000, 25000}, {1,3,5000, 50000}, {1,4,10000,100000}, {1,5,20000,200000}
};
const char *const afe_range_names[AFE_NRANGES] = {
    "10mV","20mV","50mV","100mV","200mV","500mV","1V","2V","5V","10V","20V"
};

static const uint32_t tdiv_tab[TB_COUNT] = {
    10, 20, 50, 100, 200, 500, 1000, 2000, 5000, 10000, 20000, 50000,
    100000, 200000, 500000, 1000000, 2000000, 5000000, 10000000, 20000000, 50000000, 100000000, 200000000, 500000000
};
const char *const tb_names[TB_COUNT] = {
    "10uS","20uS","50uS","100uS","200uS","500uS","1mS","2mS","5mS","10mS","20mS","50mS",
    "100mS","200mS","500mS","1S","2S","5S","10S","20S","50S","100S","200S","500S"
};

void tb_timer_params(uint32_t ticks, uint32_t *psc, uint32_t *arr)
{
    uint32_t p = (ticks + 65535u) / 65536u - 1u;
    *psc = p;
    *arr = ticks / (p + 1u) - 1u;
}

static uint32_t tb_ticks(int tb)         /* timer ticks per sample: 30 samples per division, limited by the ADC speed */
{
    uint64_t t = (uint64_t)tdiv_tab[tb] * 12u / 5u;      /* tdiv_us * 72 / 30 */
    return t < MIN_TICKS ? MIN_TICKS : (uint32_t)t;
}

uint32_t afe_tb_tdiv_us(int tb) { return tdiv_tab[tb]; }

static int fast_ok = FAST_ADC;
int afe_tb_fast(int tb) { return fast_ok && tb <= 1; }
void afe_fast_disable(void) { fast_ok = 0; }   /* called when the dual-ADC mode does not deliver data: 10/20 us fall back to timer mode */

int afe_tb_nsamples(int tb) { return afe_tb_fast(tb) ? 2048 : (tdiv_tab[tb] >= 10000u ? 640 : 1024); }

uint64_t afe_tb_ts_ns(int tb)
{
    if (afe_tb_fast(tb)) return FAST_TS_NS;
    uint32_t psc, arr;
    tb_timer_params(tb_ticks(tb), &psc, &arr);
    return (uint64_t)(psc + 1u) * (arr + 1u) * 1000u / 72u;
}

uint32_t afe_tb_spd_q8(int tb)
{
    return (uint32_t)((uint64_t)tdiv_tab[tb] * 1000u * 256u / afe_tb_ts_ns(tb));
}

static int cur_range = 6, cur_cpl = CPL_DC, cap_n, fast_active;

static void apply(int range, int cpl)
{
    uint32_t relay = afe_ranges[range].relay, mux = (cpl == CPL_GND) ? 6u : afe_ranges[range].mux;
    uint32_t set = (relay << PA_RELAY) | ((mux & 1u) << PA_MUX_A) | (((mux >> 1) & 1u) << (PA_MUX_A + 1)) | (((mux >> 2) & 1u) << (PA_MUX_A + 2));
    int dc = (cpl != CPL_AC), high = dc ? PA3_DC_LEVEL : !PA3_DC_LEVEL;
    int slow = (relay != afe_ranges[cur_range].relay) || ((cpl == CPL_AC) != (cur_cpl == CPL_AC));
    set |= high ? PIN(PA_ACDC) : 0u;
    GPIOA->BSRR = set | ((0x7Cu & ~set) << 16);          /* bits 2..6 */
    cur_range = range; cur_cpl = cpl;
    delay_ms(slow ? 8u : 2u);                            /* relay / optocoupler need longer than the analog switch */
}

void afe_set(int range, int cpl) { apply(range, cpl); }
void afe_set_range(int idx) { apply(idx, cur_cpl); }
void afe_set_coupling(int cpl) { apply(cur_range, cpl); }

void afe_init(void)
{
    RCC->APB2ENR |= RCC_APB2_IOPA | RCC_APB2_AFIO | RCC_APB2_ADC1 | RCC_APB2_ADC2;
    RCC->APB1ENR |= RCC_APB1_TIM2 | RCC_APB1_TIM3;
    RCC->AHBENR  |= RCC_AHB_DMA1;

    gpio_cfg(GPIOA, PA_ADC_IN, CFG_ANALOG);
    gpio_cfg(GPIOA, PA_VBAT, CFG_ANALOG);
    gpio_cfg(GPIOA, PA_RELAY, CFG_OUT_2);
    gpio_cfg(GPIOA, PA_ACDC, CFG_OUT_2);
    gpio_cfg(GPIOA, PA_MUX_A, CFG_OUT_2); gpio_cfg(GPIOA, PA_MUX_A + 1, CFG_OUT_2); gpio_cfg(GPIOA, PA_MUX_A + 2, CFG_OUT_2);
    gpio_cfg(GPIOA, PA_CALIB, CFG_OUT_2); GPIOA->BRR = PIN(PA_CALIB);

    ADC1->CR2 = 1u;                                             /* ADON */
    delay_ms(2);
    ADC1->CR2 |= (1u << 3); while (ADC1->CR2 & (1u << 3)) { }   /* RSTCAL */
    ADC1->CR2 |= (1u << 2); while (ADC1->CR2 & (1u << 2)) { }   /* CAL */
    ADC2->CR2 = 1u;
    delay_ms(2);
    ADC2->CR2 |= (1u << 3); while (ADC2->CR2 & (1u << 3)) { }
    ADC2->CR2 |= (1u << 2); while (ADC2->CR2 & (1u << 2)) { }
    ADC2->CR2 = 0;
    apply(cur_range, cur_cpl);
}

void afe_gen_set(uint32_t freq_hz, int duty_pct, int on)
{
    if (!on || duty_pct <= 0 || duty_pct >= 100 || freq_hz == 0) {
        TIM2->CR1 = 0; TIM2->CCER = 0;
        gpio_cfg(GPIOA, PA_CALIB, CFG_OUT_2);
        if (on && duty_pct >= 100) GPIOA->BSRR = PIN(PA_CALIB); else GPIOA->BRR = PIN(PA_CALIB);
    } else {
        uint32_t psc, arr, ticks = TIM_CLK_HZ / freq_hz;
        if (ticks < 2) ticks = 2;
        tb_timer_params(ticks, &psc, &arr);
        TIM2->CR1 = 0;
        TIM2->PSC = psc; TIM2->ARR = arr;
        TIM2->CCR1 = (uint32_t)(((uint64_t)(arr + 1u) * (uint32_t)duty_pct) / 100u);
        TIM2->CCMR1 = (6u << 4) | (1u << 3);                    /* PWM mode 1, preload */
        TIM2->CCER = 1u;
        TIM2->EGR = 1u;
        TIM2->CR1 = 1u;
        gpio_cfg(GPIOA, PA_CALIB, CFG_AF_50);
    }
}

uint16_t adc_read_sw(int ch)
{
    ADC1->CR1 = 0;                                              /* single ADC mode */
    ADC1->CR2 = 1u;
    ADC1->SQR1 = 0; ADC1->SQR3 = (uint32_t)ch;
    ADC1->SMPR2 |= (7u << (3 * ch));                            /* 239.5 cycles */
    ADC1->CR2 = 1u | (7u << 17) | (1u << 20);                   /* EXTTRIG with SWSTART */
    (void)ADC1->DR;                                             /* drop stale data and the stale EOC flag of a DMA capture */
    ADC1->SR = 0;
    ADC1->CR2 |= (1u << 22);
    while (!(ADC1->SR & 2u)) { }
    return (uint16_t)ADC1->DR;
}

uint16_t adc_read_avg(int ch, int count)
{
    uint32_t s = 0; int i;
    (void)adc_read_sw(ch);
    for (i = 0; i < count; i++) s += adc_read_sw(ch);
    return (uint16_t)(s / (uint32_t)count);
}

uint16_t adc_avg_input(int count) { return adc_read_avg(1, count); }

void adc_capture_start(int tb, uint16_t *buf, int n, int circular)
{
    uint32_t psc, arr, ticks = tb_ticks(tb), smp;
    tb_timer_params(ticks, &psc, &arr);
    smp = (ticks <= 240u) ? 0u : (ticks <= 2400u ? 2u : 5u);    /* 1.5 / 7.5 / 55.5 cycles by sample rate */
    TIM3->CR1 = 0;
    cap_n = n;
    DMA1->CH[0].CCR = 0;
    DMA1->IFCR = 0xFu;
    DMA1->CH[0].CPAR = (uint32_t)&ADC1->DR;
    DMA1->CH[0].CMAR = (uint32_t)buf;
    DMA1->CH[0].CNDTR = (uint32_t)n;
    DMA1->CH[0].CCR = (1u << 7) | (1u << 8) | (1u << 10) | (2u << 12) | (circular ? (1u << 5) : 0u) | 1u;
    ADC1->CR1 = 0;                                              /* single ADC mode */
    ADC1->SMPR2 = (ADC1->SMPR2 & ~(7u << 3)) | (smp << 3);
    ADC1->SQR1 = 0; ADC1->SQR3 = 1;
    ADC1->CR2 = 1u | (1u << 8) | (1u << 20) | (4u << 17);       /* ADON, DMA, EXTTRIG, TIM3_TRGO */
    TIM3->PSC = psc; TIM3->ARR = arr; TIM3->CNT = 0;
    TIM3->CR2 = (2u << 4);                                      /* TRGO = update event */
    TIM3->SR = 0;
    TIM3->EGR = 1u;
    TIM3->CR1 = 1u;
}

int adc_capture_done(void) { return (DMA1->ISR & (1u << 1)) != 0; }

int adc_capture_wrapped(void)
{
    if (DMA1->ISR & (1u << 1)) { DMA1->IFCR = (1u << 1); return 1; }
    return 0;
}

int adc_capture_pos(void) { return cap_n - (int)DMA1->CH[0].CNDTR; }   /* next sample to be written (circular mode) */

static void adc_prescaler(int div4)
{
    RCC->CFGR = (RCC->CFGR & ~(3u << 14)) | (div4 ? (1u << 14) : (2u << 14));   /* /4 = 18 MHz (stock firmware does this), /6 = 12 MHz */
}

void adc_capture_start_fast(uint32_t *words, int n_words)
{
    volatile int d;
    TIM3->CR1 = 0;
    DMA1->CH[0].CCR = 0; DMA1->IFCR = 0xFu;
    ADC1->CR2 = 0; ADC2->CR2 = 0;
    adc_prescaler(1); fast_active = 1;
    ADC1->SMPR2 &= ~(7u << 3); ADC2->SMPR2 &= ~(7u << 3);      /* 1.5 cycles */
    ADC1->SQR1 = 0; ADC1->SQR3 = 1; ADC2->SQR1 = 0; ADC2->SQR3 = 1;
    ADC1->CR1 = (7u << 16);                                      /* DUALMOD = fast interleaved */
    ADC1->CR2 = 1u; ADC2->CR2 = 1u;
    for (d = 0; d < 400; d++) { }                                /* ADC wake-up */
    ADC2->CR2 = 1u | (1u << 20) | (7u << 17);                    /* slave: external trigger taken from the master (no CONT: with CONT ADC2 delivered nothing) */
    cap_n = n_words;
    DMA1->CH[0].CPAR = (uint32_t)&ADC1->DR;
    DMA1->CH[0].CMAR = (uint32_t)words;
    DMA1->CH[0].CNDTR = (uint32_t)n_words;
    DMA1->CH[0].CCR = (1u << 7) | (2u << 8) | (2u << 10) | (2u << 12) | 1u;   /* MINC, 32-bit, 32-bit, high priority, enable */
    ADC1->CR2 = 1u | (1u << 1) | (1u << 8) | (1u << 20) | (7u << 17);       /* ADON, CONT, DMA, EXTTRIG + SWSTART select */
    ADC1->CR2 |= (1u << 22);                                                /* SWSTART */
}

void adc_capture_stop(void)
{
    TIM3->CR1 = 0;
    DMA1->CH[0].CCR = 0;
    DMA1->IFCR = 0xFu;
    ADC1->CR2 = 1u;
    if (fast_active) {
        ADC2->CR2 = 0; ADC1->CR1 = 0;
        adc_prescaler(0); fast_active = 0;
    }
}
