#ifndef AFE_H
#define AFE_H
#include <stdint.h>

/* ---- vertical ranges (taken from the stock firmware) ----
   label_mv: what the stock firmware prints (10mV ... 20V). phys_x10: real mV/div * 10 derived from the stock
   scaling table (20000/table): the first, second and eighth range are really 12.5 mV, 25 mV and 2.5 V per division. */
#define AFE_NRANGES 11
typedef struct { uint8_t relay; uint8_t mux; uint16_t label_mv; uint32_t phys_x10; } afe_range_t;
extern const afe_range_t afe_ranges[AFE_NRANGES];
extern const char *const afe_range_names[AFE_NRANGES];

/* ---- time bases: 10 us ... 500 s per division (24 steps, like the stock firmware) ---- */
#define TB_COUNT 24
#define TB_ROLL_FROM 11            /* index of 50 ms/div: this and slower time bases run in roll mode (no trigger) */
extern const char *const tb_names[TB_COUNT];
uint32_t afe_tb_tdiv_us(int tb);
uint64_t afe_tb_ts_ns(int tb);      /* sample period in ns */
uint32_t afe_tb_spd_q8(int tb);     /* samples per division << 8 */
void     afe_set_turbo(int on);     /* 1 = fast sampling for 10/20 us/div (ADC at 36 MHz, ~2.4 MS/s) */
int      afe_tb_fast(int tb);       /* 1 = dual interleaved ADC mode (10 and 20 us/div, 2.57 MS/s) */
void     afe_fast_disable(void);    /* fall back to timer-triggered sampling for 10/20 us */
int      afe_tb_nsamples(int tb);   /* samples captured per frame (fast mode: 2048) */

/* ---- coupling ---- */
enum { CPL_DC, CPL_AC, CPL_GND };

void afe_init(void);
void afe_set(int range, int cpl);
void afe_set_range(int idx);
void afe_set_coupling(int cpl);
void afe_gen_set(uint32_t freq_hz, int duty_pct, int on);   /* PA0 generator: TIM2_CH1 PWM */

uint16_t adc_read_sw(int channel);
uint16_t adc_read_avg(int channel, int count);
uint16_t adc_avg_input(int count);
void adc_capture_start(int tb_idx, uint16_t *buf, int n, int circular);
int  adc_capture_done(void);        /* one-shot: all samples written */
int  adc_capture_wrapped(void);     /* circular: returns 1 and clears the flag after each full lap */
int  adc_capture_pos(void);         /* index of the next sample to be written */
void adc_capture_start_fast(uint32_t *words, int n_words);   /* ADC1+ADC2 interleaved, each word = 2 samples (low = first) */
void adc_capture_stop(void);

void tb_timer_params(uint32_t ticks, uint32_t *psc, uint32_t *arr);   /* pure function (unit tested) */
#endif
