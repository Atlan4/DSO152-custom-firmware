#ifndef FLASHCAL_H
#define FLASHCAL_H
#include <stdint.h>
#include "afe.h"
#define CAL_ADDR  0x0800F800u        /* our own page; stock firmware kept its data at 0x0800FC00 */
#define CAL_MAGIC 0xD5152C02u
/* indices into cal_t.user[] (user settings that survive power off) */
enum { U_RANGE, U_TB, U_CPL, U_RISING, U_TMODE, U_VIEW, U_VPOS, U_TLEVEL, U_HPOS,
       U_GEN_ON, U_GEN_FI, U_GEN_DUTY, U_BRIGHT, U_PROBE, U_SPARE1, U_SPARE2, U_COUNT };

typedef struct {
    uint32_t magic;
    uint16_t zero[AFE_NRANGES];      /* ADC counts at 0 V per range */
    uint16_t pad;
    uint32_t k_q8;                   /* ADC counts per division << 8 */
    int16_t  user[U_COUNT];
    uint32_t check;
} cal_t;
void cal_defaults(cal_t *c);          /* everything */
void cal_defaults_user(cal_t *c);     /* only the user settings, calibration is kept */
int  cal_load(cal_t *c);             /* returns 1 if valid data was found, else fills defaults and returns 0 */
int  cal_save(const cal_t *c);       /* returns 1 on success */
void cal_save_status(int *last_ok, uint32_t *saves, uint32_t *fails);   /* last_ok: -1 never saved, 0 failed, 1 ok */
#endif
