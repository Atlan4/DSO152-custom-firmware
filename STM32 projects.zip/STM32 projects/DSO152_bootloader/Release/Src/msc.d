Src/msc.o: ../Src/msc.c ../Inc/hw.h ../Inc/msc.h ../Inc/vdisk.h
../Inc/hw.h:
../Inc/msc.h:
../Inc/vdisk.h:
