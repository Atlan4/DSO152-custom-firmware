Src/main.o: ../Src/main.c ../Inc/hw.h ../Inc/lcd.h ../Inc/vdisk.h \
 ../Inc/msc.h
../Inc/hw.h:
../Inc/lcd.h:
../Inc/vdisk.h:
../Inc/msc.h:
