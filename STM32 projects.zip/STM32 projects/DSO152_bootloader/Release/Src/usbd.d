Src/usbd.o: ../Src/usbd.c ../Inc/hw.h ../Inc/msc.h
../Inc/hw.h:
../Inc/msc.h:
