Src/flashw.o: ../Src/flashw.c ../Inc/hw.h ../Inc/flashw.h
../Inc/hw.h:
../Inc/flashw.h:
