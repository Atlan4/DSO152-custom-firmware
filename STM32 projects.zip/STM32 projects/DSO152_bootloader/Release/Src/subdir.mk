################################################################################
# Automatically-generated file. Do not edit!
# Toolchain: GNU Tools for STM32 (14.3.rel1)
################################################################################

# Add inputs and outputs from these tool invocations to the build variables 
C_SRCS += \
../Src/flashw.c \
../Src/font5x7.c \
../Src/lcd.c \
../Src/main.c \
../Src/msc.c \
../Src/startup.c \
../Src/usbd.c \
../Src/vdisk.c 

OBJS += \
./Src/flashw.o \
./Src/font5x7.o \
./Src/lcd.o \
./Src/main.o \
./Src/msc.o \
./Src/startup.o \
./Src/usbd.o \
./Src/vdisk.o 

C_DEPS += \
./Src/flashw.d \
./Src/font5x7.d \
./Src/lcd.d \
./Src/main.d \
./Src/msc.d \
./Src/startup.d \
./Src/usbd.d \
./Src/vdisk.d 


# Each subdirectory must supply rules for building sources it contributes
Src/%.o Src/%.su Src/%.cyclo: ../Src/%.c Src/subdir.mk
	arm-none-eabi-gcc "$<" -mcpu=cortex-m3 -std=gnu11 -DSTM32 -DSTM32F1 -DSTM32F103R8Tx -c -I../Inc -Os -ffunction-sections -fdata-sections -Wall -fstack-usage -fcyclomatic-complexity -MMD -MP -MF"$(@:%.o=%.d)" -MT"$@" --specs=nano.specs -mfloat-abi=soft -mthumb -o "$@"

clean: clean-Src

clean-Src:
	-$(RM) ./Src/flashw.cyclo ./Src/flashw.d ./Src/flashw.o ./Src/flashw.su ./Src/font5x7.cyclo ./Src/font5x7.d ./Src/font5x7.o ./Src/font5x7.su ./Src/lcd.cyclo ./Src/lcd.d ./Src/lcd.o ./Src/lcd.su ./Src/main.cyclo ./Src/main.d ./Src/main.o ./Src/main.su ./Src/msc.cyclo ./Src/msc.d ./Src/msc.o ./Src/msc.su ./Src/startup.cyclo ./Src/startup.d ./Src/startup.o ./Src/startup.su ./Src/usbd.cyclo ./Src/usbd.d ./Src/usbd.o ./Src/usbd.su ./Src/vdisk.cyclo ./Src/vdisk.d ./Src/vdisk.o ./Src/vdisk.su

.PHONY: clean-Src

