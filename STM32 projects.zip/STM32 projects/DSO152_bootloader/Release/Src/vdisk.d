Src/vdisk.o: ../Src/vdisk.c ../Inc/hw.h ../Inc/vdisk.h ../Inc/flashw.h
../Inc/hw.h:
../Inc/vdisk.h:
../Inc/flashw.h:
