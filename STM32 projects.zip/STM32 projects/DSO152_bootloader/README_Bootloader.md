# DSO152 USB bootloader

Bootloader v pamati 0x08000000 - 0x08003BFF. Aplikacia (originalna `DSO152_APP_V0_1.bin` alebo nas firmware) je od 0x08003C00.

## Pouzitie
1. Prvy raz nahraj `bootloader.bin` cez ST-Link na **0x08000000** (v STM32CubeProgrammer bez "full chip erase", aby ostali nastavenia a kalibracia).
2. **Aktualizacia:** drz tlacidlo **OK** a zapni pristroj (alebo v nasom firmware *Settings -> USB update*). Na displeji sa objavi "DSO152 USB BOOTLOADER".
3. Pripoj USB kabel k PC - objavi sa disk **DSO152 BOOT**. Skopiruj na neho `.bin` subor (originalny alebo nas). Zapisuje sa priamo do flash, displej ukazuje priebeh.
4. Po dokonceni: "Hotovo" - po 5 s sa firmware spusti sam, alebo hned po stlaceni lubovolneho tlacidla (alebo vypni/zapni). **RUN** ukonci rezim aktualizacie.
5. Bez drzania OK sa aplikacia spusti hned. Ak aplikacia chyba/je poskodena, bootloader sa spusti v rezime USB sam.

## Obmedzenia (poctivo)
* **Nic z toho som nemohol skompilovat pre ARM ani vyskusat na pristroji.** Logika virtualneho disku a SCSI je otestovana na PC (simulacia flash, subory 300 B - 44 KB). USB cast (usbd.c) je neotestovana na hardware.
* Predpoklad: D+ (PA12) ma pull-up (interny/externy). Bootloader na 30 ms stiahne D+ nizko, aby PC prepocital zariadenie. Ak by disk neokazal, napis mi.
* Subor sa musi kopirovat suvisle od zaciatku (bezne spravanie Windows/Linux). Zapisat sa da len do 0x08003C00 - 0x0800F7FF (max. 47 KB); iny subor sa ignoruje.
* Windows moze po kopirovani hlasit "disk sa nemoze naformatovat" - nie je to treba, disk je virtualny a po restarte zmizne.
* Bootloader nevie kopirovat naspat (citanie disku vracia prazdny obsah).

## Zostavenie v STM32CubeIDE
Novy "Empty" projekt STM32F103R8 -> vymaz vygenerovany startup a linker -> pridaj `Src/*.c`, `Inc/*.h`, linker `STM32F103R8_BOOT.ld`.
Nastav: MCU GCC Compiler -> `-Os -ffreestanding`, Linker: `-nostdlib -nostartfiles -T STM32F103R8_BOOT.ld`, Include path `Inc`. Vystup .bin musi mat < 15 KB.
Poznamka: v nasom kode nie je libc, `memcpy/memset` su v `startup.c` (ak linker hlasi duplicitu, zmaz ich).
