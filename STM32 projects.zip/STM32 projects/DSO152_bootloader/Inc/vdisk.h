#ifndef VDISK_H
#define VDISK_H
#include <stdint.h>
#ifndef APP_BASE
#define APP_BASE  0x08003C00u
#define APP_LIMIT 0x0800F800u
#endif
/* Tiny FAT12 volume (1 MB, 1 sector per cluster). It only exists in RAM; a firmware .bin copied onto it is programmed into the
   application slot while it arrives. The start of the image is recognised by its vector table (stack pointer in RAM, odd reset
   vector inside the slot), so extra files that the PC may write (System Volume Information ...) are ignored. */
#define VD_SECTORS      2048u
#define VD_FAT_SECTORS  6u
#define VD_ROOT_SECTORS 2u
#define VD_DATA_LBA     15u
enum { VD_IDLE, VD_RECEIVING, VD_DONE, VD_ERROR };
void vdisk_init(void);
void vdisk_read(uint32_t lba, uint8_t *buf);
void vdisk_write(uint32_t lba, const uint8_t *buf);
void vdisk_poll(uint32_t now_ms);          /* call often: finishes the transfer */
int  vdisk_state(void);
uint32_t vdisk_total(void);                /* file size once the PC has written the directory entry, else 0 */
uint32_t vdisk_dbg(int which);              /* 0 error code, 1 dropped sectors, 2 last sector index, 3 sectors received */
uint32_t vdisk_bytes(void);                /* bytes received so far / total when done */
#endif
