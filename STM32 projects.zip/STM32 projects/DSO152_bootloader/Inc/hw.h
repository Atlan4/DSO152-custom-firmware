/* Register definitions for the DSO152 USB bootloader (STM32F103R8 / CH32F103R8). */
#ifndef HW_H
#define HW_H
#include <stdint.h>
#define IO volatile
typedef struct { IO uint32_t CRL, CRH, IDR, ODR, BSRR, BRR, LCKR; } GPIO_TypeDef;
typedef struct { IO uint32_t CR, CFGR, CIR, APB2RSTR, APB1RSTR, AHBENR, APB2ENR, APB1ENR, BDCR, CSR; } RCC_TypeDef;
typedef struct { IO uint32_t EVCR, MAPR, EXTICR[4]; } AFIO_TypeDef;
typedef struct { IO uint32_t ACR, KEYR, OPTKEYR, SR, CR, AR; } FLASH_TypeDef;
#define GPIOA ((GPIO_TypeDef *)0x40010800u)
#define GPIOB ((GPIO_TypeDef *)0x40010C00u)
#define GPIOC ((GPIO_TypeDef *)0x40011000u)
#define RCC   ((RCC_TypeDef *)0x40021000u)
#define AFIO  ((AFIO_TypeDef *)0x40010000u)
#define FLASH ((FLASH_TypeDef *)0x40022000u)
#define SCB_VTOR  (*(IO uint32_t *)0xE000ED08u)
#define SCB_AIRCR (*(IO uint32_t *)0xE000ED0Cu)
#define STK_CTRL  (*(IO uint32_t *)0xE000E010u)
#define STK_LOAD  (*(IO uint32_t *)0xE000E014u)
#define STK_VAL   (*(IO uint32_t *)0xE000E018u)
#define RCC_APB2_AFIO (1u << 0)
#define RCC_APB2_IOPA (1u << 2)
#define RCC_APB2_IOPB (1u << 3)
#define RCC_APB2_IOPC (1u << 4)
#define CFG_IN_FLOAT 0x4u
#define CFG_IN_PULL  0x8u
#define CFG_OUT_2    0x2u
#define CFG_OUT_50   0x3u
static inline void gpio_cfg(GPIO_TypeDef *g, int pin, uint32_t cfg)
{
    IO uint32_t *r = (pin < 8) ? &g->CRL : &g->CRH;
    int sh = (pin & 7) * 4;
    *r = (*r & ~(0xFu << sh)) | (cfg << sh);
}
#define PIN(n) (1u << (n))
#ifndef HOST_CHECK
#define NOP() __asm volatile("nop")
#else
#define NOP() ((void)0)
#endif

/* USB device peripheral and its packet memory */
#define USB_EPR(n)  (*(IO uint32_t *)(0x40005C00u + 4u * (n)))
#define USB_CNTR    (*(IO uint32_t *)0x40005C40u)
#define USB_ISTR    (*(IO uint32_t *)0x40005C44u)
#define USB_DADDR   (*(IO uint32_t *)0x40005C4Cu)
#define USB_BTABLE  (*(IO uint32_t *)0x40005C50u)
#define PMA16(byte_off) (*(IO uint16_t *)(0x40006000u + 2u * (byte_off)))

/* flash map: 0x08000000 bootloader (15 KB) | 0x08003C00 application slot (to 0x0800F7FF) | 0x0800F800 app settings | 0x0800FC00 original app calibration */
#define APP_BASE   0x08003C00u
#define APP_LIMIT  0x0800F800u
#define BOOT_MAGIC_ADDR 0x20004FF0u      /* the application writes BOOT_MAGIC here to request USB update mode */
#define BOOT_MAGIC 0xB007DF11u

/* pins */
#define PA_LCD_RST 8
#define PA_BTN_DOWN 9
#define PA_BTN_RUN 10
#define PA_USB_DM 11
#define PA_USB_DP 12
#define PA_LCD_CS 15
#define PC_BTN_LEFT 3
#define PC_BTN_OK 4
#define PC_BTN_RIGHT 5
#define PC_BTN_UP 6
#define PC_LCD_BL 9
#define PC_PWR_LATCH 10
#define PC_BTN_POWER 11
#define PC_LCD_RS 13
#define PC_LCD_WR 14
#define PC_LCD_RD 15

extern volatile uint32_t g_ms;
void delay_ms(uint32_t ms);
void clock_init72(void);                  /* HSE + PLL: 72 MHz, USB 48 MHz; returns with g_clk_ok set */
extern int g_clk_ok;
void systick_start(void);
void *memcpy(void *d, const void *s, __SIZE_TYPE__ n);
void *memset(void *d, int v, __SIZE_TYPE__ n);
#endif
