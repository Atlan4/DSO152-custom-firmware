#ifndef FLASHW_H
#define FLASHW_H
#include <stdint.h>
int flash_erase_page(uint32_t addr);                              /* 1 KB page; 0 = ok */
int flash_program(uint32_t addr, const uint8_t *d, uint32_t len); /* halfword programming + verify; 0 = ok */
#endif
