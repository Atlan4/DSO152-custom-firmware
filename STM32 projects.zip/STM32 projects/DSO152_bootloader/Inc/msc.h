#ifndef MSC_H
#define MSC_H
#include <stdint.h>
/* USB mass storage, bulk-only transport + the SCSI subset needed by Windows, Linux and macOS. */
void msc_init(void);
void msc_reset(void);
void msc_out(const uint8_t *d, uint16_t len);   /* called with every bulk OUT packet (<= 64 bytes) */
void msc_poll(void);                            /* sends IN data / CSW whenever the IN endpoint is free */
/* provided by usbd.c */
int  usb_tx_ready(void);
void usb_stall_in(void);                        /* stall the bulk IN endpoint until the host clears the halt */
void usb_send(const uint8_t *d, uint16_t n);
uint32_t msc_dbg(int which);                  /* 0 last SCSI opcode, 1 state, 2 sectors left (write), 3 bytes left (read) */
uint32_t usb_dbg2(int which);                   /* 0 bus resets, 1 BOT resets, 2 clear-halts, 3 ISTR.ERR, 4 PMAOVR, 5 last control request (bm<<8|bReq) */
uint32_t usb_dbg(void);                         /* bit0 configured, bit1 tx busy, bit2 halted */
#endif
