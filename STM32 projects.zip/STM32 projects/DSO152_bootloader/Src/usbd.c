/* Minimal USB full-speed device core (STM32F103 USB peripheral, polled - no interrupts) for the mass-storage class.
   PMA layout: BTABLE 0..63, EP0 TX 64, EP0 RX 128, EP1 TX 192, EP1 RX 256 (64 bytes each). */
#include "hw.h"
#include "msc.h"

#define EP0_TX 64u
#define EP0_RX 128u
#define EP1_TX 192u
#define EP1_RX 256u
#define BT(n, i) (8u * (n) + 2u * (i))        /* i: 0 ADDR_TX, 1 COUNT_TX, 2 ADDR_RX, 3 COUNT_RX */
#define EPR_KEEP 0x0F0Fu
#define ST_TX_NAK 0x20u
#define ST_TX_VALID 0x30u
#define ST_TX_STALL 0x10u
#define ST_RX_NAK 0x2000u
#define ST_RX_VALID 0x3000u

static const uint8_t dev_desc[18] = { 18, 1, 0x00, 0x02, 0, 0, 0, 64, 0x09, 0x12, 0x01, 0x00, 0x00, 0x01, 1, 2, 3, 1 };   /* VID 1209 PID 0001 (open test ids) */
static const uint8_t cfg_desc[32] = {
    9, 2, 32, 0, 1, 1, 0, 0x80, 50,
    9, 4, 0, 0, 2, 8, 6, 0x50, 0,                  /* mass storage, SCSI transparent, bulk-only */
    7, 5, 0x81, 2, 64, 0, 0,
    7, 5, 0x01, 2, 64, 0, 0
};
static const char *const strs[3] = { "DSO152", "DSO152 USB Bootloader", "000000000152" };

static uint32_t n_rst, n_bot, n_clr, n_err, n_ovr, last_req;
static uint8_t cfgd, tx_busy, halted_in, have_addr, new_addr;
static const uint8_t *c_ptr;
static uint16_t c_left, c_last;
static uint8_t c_zlp, strbuf[64], rxb[64];

static void pma_write(uint32_t off, const uint8_t *d, uint16_t n)
{
    uint16_t i;
    for (i = 0; i < n; i += 2) {
        uint16_t w = d[i];
        if (i + 1 < n) w |= (uint16_t)((uint16_t)d[i + 1] << 8);
        PMA16(off + i) = w;
    }
}
static void pma_read(uint32_t off, uint8_t *d, uint16_t n)
{
    uint16_t i;
    for (i = 0; i < n; i += 2) {
        uint16_t w = PMA16(off + i);
        d[i] = (uint8_t)w;
        if (i + 1 < n) d[i + 1] = (uint8_t)(w >> 8);
    }
}

static void ep_stat_tx(int n, uint32_t s) { uint32_t v = USB_EPR(n); USB_EPR(n) = (v & EPR_KEEP) | 0x8080u | ((v ^ s) & 0x30u); }
static void ep_stat_rx(int n, uint32_t s) { uint32_t v = USB_EPR(n); USB_EPR(n) = (v & EPR_KEEP) | 0x8080u | ((v ^ s) & 0x3000u); }
static void clr_ctr_rx(int n) { USB_EPR(n) = (USB_EPR(n) & EPR_KEEP) | 0x0080u; }
static void clr_ctr_tx(int n) { USB_EPR(n) = (USB_EPR(n) & EPR_KEEP) | 0x8000u; }
static void ep_dtog_clear(int n)
{
    uint32_t v = USB_EPR(n), w = (v & EPR_KEEP) | 0x8080u;
    if (v & 0x4000u) w |= 0x4000u;
    if (v & 0x0040u) w |= 0x0040u;
    USB_EPR(n) = w;
}

static void usb_reset_ep(void)
{
    PMA16(BT(0, 0)) = EP0_TX; PMA16(BT(0, 1)) = 0; PMA16(BT(0, 2)) = EP0_RX; PMA16(BT(0, 3)) = 0x8400;
    PMA16(BT(1, 0)) = EP1_TX; PMA16(BT(1, 1)) = 0; PMA16(BT(1, 2)) = EP1_RX; PMA16(BT(1, 3)) = 0x8400;
    USB_EPR(0) = (1u << 9);                       /* control, EA 0 */
    ep_stat_rx(0, ST_RX_VALID); ep_stat_tx(0, ST_TX_NAK);
    USB_EPR(1) = 1u;                              /* bulk, EA 1 */
    ep_stat_rx(1, ST_RX_VALID); ep_stat_tx(1, ST_TX_NAK);
    USB_DADDR = 0x80u;
    cfgd = 0; tx_busy = 0; halted_in = 0; have_addr = 0;
    n_rst++;
    msc_reset();
}

static void ep0_chunk(void)
{
    uint16_t n = c_left > 64 ? 64 : c_left;
    pma_write(EP0_TX, c_ptr, n);
    PMA16(BT(0, 1)) = n;
    c_ptr += n; c_left -= n; c_last = n;
    ep_stat_tx(0, ST_TX_VALID);
}
static void ep0_in(const uint8_t *p, uint16_t len, uint16_t wlen)
{
    c_zlp = (len < wlen);
    if (len > wlen) len = wlen;
    c_ptr = p; c_left = len;
    ep0_chunk();
    ep_stat_rx(0, ST_RX_VALID);
}
static void ep0_ack(void) { c_ptr = rxb; c_left = 0; c_zlp = 0; ep0_chunk(); ep_stat_rx(0, ST_RX_VALID); }
static void ep0_stall(void) { ep_stat_tx(0, ST_TX_STALL); ep_stat_rx(0, 0x1000u); }

static void get_string(int idx, uint16_t wl)
{
    int i = 0;
    if (idx == 0) { strbuf[0] = 4; strbuf[1] = 3; strbuf[2] = 0x09; strbuf[3] = 0x04; ep0_in(strbuf, 4, wl); return; }
    if (idx > 3) { ep0_stall(); return; }
    {
        const char *s = strs[idx - 1];
        while (s[i] && i < 30) { strbuf[2 + 2 * i] = (uint8_t)s[i]; strbuf[3 + 2 * i] = 0; i++; }
    }
    strbuf[0] = (uint8_t)(2 + 2 * i); strbuf[1] = 3;
    ep0_in(strbuf, strbuf[0], wl);
}

static void setup(const uint8_t *s)
{
    uint8_t bm = s[0], rq = s[1];
    last_req = ((uint32_t)bm << 8) | rq;
    uint16_t wv = (uint16_t)(s[2] | (s[3] << 8)), wi = (uint16_t)(s[4] | (s[5] << 8)), wl = (uint16_t)(s[6] | (s[7] << 8));
    static uint8_t one[2];
    if ((bm & 0x60) == 0) {
        switch (rq) {
        case 6:
            if ((wv >> 8) == 1) ep0_in(dev_desc, 18, wl);
            else if ((wv >> 8) == 2) ep0_in(cfg_desc, 32, wl);
            else if ((wv >> 8) == 3) get_string(wv & 0xFF, wl);
            else ep0_stall();
            break;
        case 5: new_addr = (uint8_t)(wv & 0x7F); have_addr = 1; ep0_ack(); break;
        case 9: cfgd = (uint8_t)wv; ep_dtog_clear(1); ep0_ack(); break;
        case 8: one[0] = cfgd; ep0_in(one, 1, wl); break;
        case 0: one[0] = 0; one[1] = 0; ep0_in(one, 2, wl); break;
        case 10: one[0] = 0; ep0_in(one, 1, wl); break;
        case 11: ep0_ack(); break;
        case 1:
            if (bm == 2 && wv == 0 && (wi & 0xF) == 1) {           /* CLEAR_FEATURE(ENDPOINT_HALT) */
                ep_dtog_clear(1); n_clr++;
                if (wi & 0x80) { halted_in = 0; tx_busy = 0; ep_stat_tx(1, ST_TX_NAK); }
                else ep_stat_rx(1, ST_RX_VALID);
            }
            ep0_ack(); break;
        default: ep0_stall(); break;
        }
    } else if ((bm & 0x60) == 0x20) {
        if (rq == 0xFE) { one[0] = 0; ep0_in(one, 1, wl); }          /* GET_MAX_LUN */
        else if (rq == 0xFF) {                                       /* bulk-only mass storage reset */
            msc_reset(); ep_dtog_clear(1); halted_in = 0; tx_busy = 0; n_bot++;
            ep_stat_tx(1, ST_TX_NAK); ep_stat_rx(1, ST_RX_VALID); ep0_ack();
        } else ep0_stall();
    } else ep0_stall();
}

void usb_init(void)
{
    volatile int i;
    RCC->APB2ENR |= RCC_APB2_IOPA;
    gpio_cfg(GPIOA, PA_USB_DP, CFG_OUT_2); GPIOA->BRR = PIN(PA_USB_DP);   /* pull D+ low: forces the host to re-enumerate */
    delay_ms(30);
    gpio_cfg(GPIOA, PA_USB_DP, CFG_IN_FLOAT); gpio_cfg(GPIOA, PA_USB_DM, CFG_IN_FLOAT);
    RCC->APB1ENR |= (1u << 23);                                           /* USB clock */
    USB_CNTR = 1u;                                                        /* FRES, power on */
    for (i = 0; i < 2000; i++) { }
    USB_CNTR = 0; USB_ISTR = 0; USB_BTABLE = 0; USB_DADDR = 0x80u;
    cfgd = 0; tx_busy = 0; halted_in = 0; have_addr = 0;
}

void usb_shutdown(void)
{
    USB_CNTR = 3u;                                                        /* PDWN | FRES */
    RCC->APB1RSTR |= (1u << 23); RCC->APB1RSTR &= ~(1u << 23);
    RCC->APB1ENR &= ~(1u << 23);
}

uint32_t usb_dbg2(int w) { return w == 0 ? n_rst : w == 1 ? n_bot : w == 2 ? n_clr : w == 3 ? n_err : w == 4 ? n_ovr : last_req; }
uint32_t usb_dbg(void) { return (cfgd ? 1u : 0u) | (tx_busy ? 2u : 0u) | (halted_in ? 4u : 0u); }
int usb_tx_ready(void) { return cfgd && !tx_busy && !halted_in; }
void usb_stall_in(void) { halted_in = 1; ep_stat_tx(1, ST_TX_STALL); }
void usb_send(const uint8_t *d, uint16_t n)
{
    pma_write(EP1_TX, d, n);
    PMA16(BT(1, 1)) = n;
    tx_busy = 1;
    ep_stat_tx(1, ST_TX_VALID);
}

void usb_poll(void)
{
    uint32_t s = USB_ISTR;
    if (s & 0x0400u) { USB_ISTR = 0xFBFFu; usb_reset_ep(); }
    if (s & 0x2000u) { n_err++; USB_ISTR = 0xDFFFu; }     /* ERR: CRC / timeout / bit-stuff error */
    if (s & 0x4000u) { n_ovr++; USB_ISTR = 0xBFFFu; }     /* PMAOVR: packet memory over/underrun */
    if (s & 0x0800u) USB_ISTR = 0xF7FFu;          /* suspend: ignored */
    if (s & 0x1000u) USB_ISTR = 0xEFFFu;          /* wake-up */
    while (((s = USB_ISTR) & 0x8000u) != 0) {
        int ep = (int)(s & 0xF);
        uint32_t e;
        if (ep > 1) break;
        e = USB_EPR(ep);                           /* the per-endpoint flags tell IN from OUT (ISTR.DIR is not used) */
        if (e & 0x0080u) {                         /* CTR_TX: IN transfer completed */
            clr_ctr_tx(ep);
            if (ep == 0) {
                if (have_addr) { USB_DADDR = 0x80u | new_addr; have_addr = 0; }
                else if (c_left > 0 || (c_last == 64 && c_zlp)) { if (c_left == 0) c_zlp = 0; ep0_chunk(); }
            } else tx_busy = 0;
        }
        if (e & 0x8000u) {                         /* CTR_RX: OUT or SETUP received */
            if (ep == 0) {
                if (e & 0x0800u) { pma_read(EP0_RX, rxb, 8); clr_ctr_rx(0); setup(rxb); }
                else { clr_ctr_rx(0); ep_stat_rx(0, ST_RX_VALID); }
            } else {
                uint16_t n = (uint16_t)(PMA16(BT(1, 3)) & 0x3FFu);
                if (n > 64) n = 64;
                pma_read(EP1_RX, rxb, n);
                clr_ctr_rx(1);
                msc_out(rxb, n);
                ep_stat_rx(1, ST_RX_VALID);
            }
        }
    }
}
