#include "hw.h"
#include "msc.h"
#include "vdisk.h"

enum { S_CBW, S_OUT, S_IN, S_CSW };
static uint8_t last_op, dir_in, st, status, sk, asc, small[64], secbuf[512];
static uint32_t tag, dlen, sent, lba, count, rd_lba, rd_count, tx_left;
static const uint8_t *tx_ptr;
static uint16_t fill;

static uint32_t le32(const uint8_t *p) { return (uint32_t)p[0] | ((uint32_t)p[1] << 8) | ((uint32_t)p[2] << 16) | ((uint32_t)p[3] << 24); }
static uint32_t be32(const uint8_t *p) { return ((uint32_t)p[0] << 24) | ((uint32_t)p[1] << 16) | ((uint32_t)p[2] << 8) | p[3]; }
static void wbe32(uint8_t *p, uint32_t v) { p[0] = (uint8_t)(v >> 24); p[1] = (uint8_t)(v >> 16); p[2] = (uint8_t)(v >> 8); p[3] = (uint8_t)v; }

void msc_init(void) { msc_reset(); sk = 0; asc = 0; }
void msc_reset(void) { st = S_CBW; fill = 0; tx_left = 0; rd_count = 0; }

static void finish(void) { st = S_CSW; tx_left = 0; rd_count = 0; }
static void fail(uint8_t key, uint8_t a) { status = 1; sk = key; asc = a; if (dlen && dir_in) usb_stall_in(); }

static void respond(const uint8_t *src, uint32_t n)
{
    if (n > dlen) n = dlen;
    memcpy(small, src, n);
    tx_ptr = small; tx_left = n; rd_count = 0; st = S_IN;
    if (n == 0) finish();
}

static void command(const uint8_t *cb)
{
    uint8_t t[36];
    status = 0; sent = 0; last_op = cb[0];
    switch (cb[0]) {
    case 0x00: case 0x1B: case 0x1E: case 0x2F: case 0x35:   /* TEST UNIT READY, START STOP, PREVENT REMOVAL, VERIFY, SYNC CACHE */
        finish(); break;
    case 0x12:                                               /* INQUIRY */
        memset(t, 0, 36); t[1] = 0x80; t[2] = 4; t[3] = 2; t[4] = 31;
        memcpy(t + 8, "DSO152  ", 8); memcpy(t + 16, "USB Bootloader  ", 16); memcpy(t + 32, "1.0 ", 4);
        respond(t, 36); break;
    case 0x03:                                               /* REQUEST SENSE */
        memset(t, 0, 18); t[0] = 0x70; t[2] = sk; t[7] = 10; t[12] = asc; sk = 0; asc = 0;
        respond(t, 18); break;
    case 0x1A:                                               /* MODE SENSE(6): not write protected */
        memset(t, 0, 4); t[0] = 3; respond(t, 4); break;
    case 0x25:                                               /* READ CAPACITY(10) */
        wbe32(t, VD_SECTORS - 1u); wbe32(t + 4, 512); respond(t, 8); break;
    case 0x23:                                               /* READ FORMAT CAPACITIES */
        memset(t, 0, 12); t[3] = 8; wbe32(t + 4, VD_SECTORS); t[8] = 2; t[10] = 2; respond(t, 12); break;
    case 0x28:                                               /* READ(10) */
        lba = be32(cb + 2); count = ((uint32_t)cb[7] << 8) | cb[8];
        if (count == 0) { finish(); break; }
        if (lba + count > VD_SECTORS) { fail(5, 0x21); finish(); break; }
        rd_lba = lba; rd_count = count; tx_left = 0; st = S_IN; break;
    case 0x2A:                                               /* WRITE(10) */
        lba = be32(cb + 2); count = ((uint32_t)cb[7] << 8) | cb[8];
        if (count == 0 || lba + count > VD_SECTORS) { fail(5, 0x21); finish(); break; }
        fill = 0; st = S_OUT; break;
    default:
        fail(5, 0x20); finish(); break;                      /* ILLEGAL REQUEST, invalid command */
    }
}

void msc_out(const uint8_t *d, uint16_t len)
{
    switch (st) {
    case S_CBW:
        if (len == 31 && le32(d) == 0x43425355u) { tag = le32(d + 4); dlen = le32(d + 8); dir_in = (d[12] & 0x80) != 0; command(d + 15); }
        break;
    case S_OUT:
        while (len--) {
            secbuf[fill++] = *d++;
            if (fill == 512) {
                vdisk_write(lba++, secbuf); fill = 0; sent += 512;
                if (--count == 0) { st = S_CSW; break; }
            }
        }
        break;
    default: break;
    }
}

void msc_poll(void)
{
    if (!usb_tx_ready()) return;
    if (st == S_IN) {
        if (tx_left == 0 && rd_count) { vdisk_read(rd_lba++, secbuf); rd_count--; tx_ptr = secbuf; tx_left = 512; }
        if (tx_left) {
            uint16_t n = tx_left > 64 ? 64 : (uint16_t)tx_left;
            usb_send(tx_ptr, n); tx_ptr += n; tx_left -= n; sent += n;
            if (!tx_left && !rd_count) st = S_CSW;
        } else st = S_CSW;
    } else if (st == S_CSW) {
        uint32_t res = dlen > sent ? dlen - sent : 0;
        small[0] = 0x55; small[1] = 0x53; small[2] = 0x42; small[3] = 0x53;
        small[4] = (uint8_t)tag; small[5] = (uint8_t)(tag >> 8); small[6] = (uint8_t)(tag >> 16); small[7] = (uint8_t)(tag >> 24);
        small[8] = (uint8_t)res; small[9] = (uint8_t)(res >> 8); small[10] = (uint8_t)(res >> 16); small[11] = (uint8_t)(res >> 24);
        small[12] = status;
        usb_send(small, 13); st = S_CBW;
    }
}

uint32_t msc_dbg(int w) { return w == 0 ? last_op : w == 1 ? st : w == 2 ? count : tx_left; }
