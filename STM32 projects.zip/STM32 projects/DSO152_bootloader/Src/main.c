/* DSO152 USB bootloader.
   Boot: if the application slot holds a valid image and OK is not held (and no update was requested by the application),
   jump to the application. Otherwise show the update screen and present a USB disk "DSO152 BOOT". Copy a firmware .bin
   (the original DSO152_APP_V0_1.bin or the custom firmware) onto it; it is written to flash at 0x08003C00 while it arrives.
   When done: any key starts the new firmware (the original FNIRSI firmware needs a power cycle instead). POWER switches off. */
#include "hw.h"
#include "lcd.h"
#include "vdisk.h"
#include "msc.h"

#define BOOT_VERSION "v0.1"
#define MARGIN_X 16                  /* left margin of all text, pixels */
#define BOOT_DEBUG 0                 /* 1 = extra status/diagnostic lines on the display */

void usb_init(void);
void usb_poll(void);
void usb_shutdown(void);

static int app_valid(void)
{
    uint32_t sp = *(volatile uint32_t *)APP_BASE, rs = *(volatile uint32_t *)(APP_BASE + 4u);
    return ((sp & 0xFFFE0000u) == 0x20000000u) && (rs & 1u) && rs > APP_BASE && rs < APP_LIMIT;
}

/* Our own firmware is linked with its stack top at 0x20004FF0; the original FNIRSI image uses a different initial SP. */
static int app_is_custom(void) { return *(volatile uint32_t *)APP_BASE == 0x20004FF0u; }

static void jump_app(void)
{
    uint32_t sp = *(volatile uint32_t *)APP_BASE, rs = *(volatile uint32_t *)(APP_BASE + 4u), t;
    *(volatile uint32_t *)BOOT_MAGIC_ADDR = 0;
    STK_CTRL = 0;
    usb_shutdown();
    RCC->CR |= 1u;                                                   /* HSI on, back to the reset clock configuration */
    for (t = 0; t < 0x20000 && !(RCC->CR & 2u); t++) { }
    RCC->CFGR = 0;
    for (t = 0; t < 0x20000 && (RCC->CFGR & 0xCu); t++) { }
    RCC->CR &= ~((1u << 24) | (1u << 16));                           /* PLL and HSE off */
    FLASH->ACR = 0x30;
    SCB_VTOR = APP_BASE;
    __asm volatile("msr msp, %0\n\tbx %1" :: "r"(sp), "r"(rs));
    for (;;) { }
}

/* ---- small text helpers (no printf) ---- */
static char *cat(char *d, const char *s) { while (*s) *d++ = *s++; *d = 0; return d; }
static char *catn(char *d, uint32_t v)
{
    char t[11]; int n = 0;
    do { t[n++] = (char)('0' + v % 10u); v /= 10u; } while (v);
    while (n) *d++ = t[--n];
    *d = 0; return d;
}
#if BOOT_DEBUG
static void hex(char *o, uint32_t v) { int i; for (i = 0; i < 8; i++) o[i] = "0123456789ABCDEF"[(v >> (28 - 4 * i)) & 15u]; o[8] = 0; }
#endif
static void line(int row, const char *s, uint16_t fg)
{
    char b[38]; int i = 0;
    while (s[i] && i < 37) { b[i] = s[i]; i++; }
    while (i < 37) b[i++] = ' ';
    b[37] = 0;
    lcd_str16(MARGIN_X, row * 24, b, fg, C_BLACK);
}

#if BOOT_DEBUG
/* Called from the fault handlers: print the faulting address, then wait. frame = stacked r0,r1,r2,r3,r12,lr,pc,psr */
#endif
void fault_report(uint32_t kind, uint32_t *frame)
{
    char b[16];
    lcd_fill(0, 0, LCD_W, LCD_H, C_BLACK); lcd_backlight(1);
    lcd_str16(MARGIN_X, 0, kind == 1 ? "BOOTLOADER FAULT" : "UNEXPECTED INTERRUPT", C_RED, C_BLACK);
    if (frame) {
        char *p = cat(b, "PC "); (void)p;
        { int i; b[0] = 'P'; b[1] = 'C'; b[2] = ' '; for (i = 0; i < 8; i++) b[3 + i] = "0123456789ABCDEF"[(frame[6] >> (28 - 4 * i)) & 15u]; b[11] = 0; }
        lcd_str16(MARGIN_X, 24, b, C_WHITE, C_BLACK);
    }
    for (;;) { }
}

/* The original FNIRSI firmware waits for the POWER button after a jump from here, so do not start it: switch off instead. */
static void show_restart_msg(void)
{
    uint32_t t0 = g_ms;
    lcd_fill(0, 0, LCD_W, LCD_H, C_BLACK);
    lcd_str16(MARGIN_X, 48, "FNIRSI original firmware", C_GREEN, C_BLACK);
    lcd_str16(MARGIN_X, 72, "is installed.", C_GREEN, C_BLACK);
    lcd_str16(MARGIN_X, 120, "Power the device off and on", C_WHITE, C_BLACK);
    lcd_str16(MARGIN_X, 144, "to start it.", C_WHITE, C_BLACK);
    lcd_str16(MARGIN_X, 192, "(unplug USB if it stays on)", C_DIM, C_BLACK);
    while ((uint32_t)(g_ms - t0) < 4000u) { }
    GPIOC->BRR = PIN(PC_PWR_LATCH);                 /* switch off (stays on only while USB powers the unit) */
    for (;;) { }
}

static int key_ok(void) { return !(GPIOC->IDR & PIN(PC_BTN_OK)); }
static int key_power(void) { return !(GPIOC->IDR & PIN(PC_BTN_POWER)); }
static int key_run(void) { return !(GPIOA->IDR & PIN(PA_BTN_RUN)); }
static int key_any(void)
{
    const uint32_t mc = PIN(PC_BTN_OK) | PIN(PC_BTN_UP) | PIN(PC_BTN_LEFT) | PIN(PC_BTN_RIGHT), ma = PIN(PA_BTN_RUN) | PIN(PA_BTN_DOWN);
    return (GPIOC->IDR & mc) != mc || (GPIOA->IDR & ma) != ma;            /* any one of them pressed (active low) */
}

/* ---- screens ---- */
static void draw_screen(int st)
{
    char b[48], *p;
    lcd_fill(0, 0, LCD_W, LCD_H, C_BLACK);
    line(0, "DSO152 USB BOOTLOADER   " BOOT_VERSION, C_CYAN);
    if (!app_valid()) line(1, "Application: none", C_ORANGE);
    else line(1, app_is_custom() ? "Application: custom firmware" : "Application: FNIRSI original", C_GREEN);
    if (!g_clk_ok) line(2, "ERROR: 8 MHz crystal not running!", C_RED);
    switch (st) {
    case VD_IDLE:
        line(4, "Connect the USB cable to a PC.", C_WHITE);
        line(5, "Copy a .bin file to the drive", C_WHITE);
        line(6, "DSO152 BOOT.", C_WHITE);
        line(9, "RUN = start app   POWER = off", C_DIM);
        break;
    case VD_RECEIVING:
        line(4, "Writing to flash...", C_TRACE);
        line(9, "Do not disconnect or switch off", C_DIM);
        break;
    case VD_DONE:
        line(4, "Flash write successful!", C_GREEN);
        p = catn(b, vdisk_bytes()); cat(p, " bytes written"); line(5, b, C_WHITE);
        lcd_fill(MARGIN_X, 150, 288, 16, C_DIM); lcd_fill(MARGIN_X + 1, 151, 286, 14, C_GREEN);
        if (app_is_custom()) { line(7, "Press any key to start it,", C_WHITE); line(8, "or POWER to switch off.", C_WHITE); }
        else { line(7, "Press any key to switch off,", C_WHITE); line(8, "then power on to start it.", C_WHITE); }
        break;
    default:
        line(4, "Flash write FAILED", C_RED);
        line(5, "Copy the file again.", C_WHITE);
#if BOOT_DEBUG
        p = catn(b, vdisk_dbg(0)); line(6, b, C_DIM); (void)p;
#endif
        line(9, "RUN = start app   POWER = off", C_DIM);
        break;
    }
}

static void draw_progress(void)
{
    char b[48], *p;
    uint32_t n = vdisk_bytes(), total = vdisk_total();
    p = catn(b, n);
    if (total) { p = cat(p, " / "); p = catn(p, total); }
    cat(p, " bytes");
    line(5, b, C_WHITE);
    lcd_fill(MARGIN_X, 150, 288, 16, C_DIM); lcd_fill(MARGIN_X + 1, 151, 286, 14, C_BLACK);
    {
        uint32_t den = total ? total : (APP_LIMIT - APP_BASE);      /* file size unknown until Windows writes the directory entry */
        if (n > den) n = den;
        lcd_fill(MARGIN_X + 1, 151, (int)(286u * n / den), 14, C_GREEN);
    }
}

int main(void)
{
    uint32_t magic, last_draw = 0, done_at = 0, pw_t = 0;
    int shown = -1, ok_held, pw_armed = 0;
    uint32_t shown_bytes = 0xFFFFFFFFu;

    RCC->APB2ENR |= RCC_APB2_AFIO | RCC_APB2_IOPA | RCC_APB2_IOPB | RCC_APB2_IOPC;
    GPIOC->BSRR = PIN(PC_PWR_LATCH); gpio_cfg(GPIOC, PC_PWR_LATCH, CFG_OUT_2);        /* keep the instrument powered */
    {
        static const uint8_t cp[] = { PC_BTN_UP, PC_BTN_LEFT, PC_BTN_RIGHT, PC_BTN_OK, PC_BTN_POWER };
        int i;
        for (i = 0; i < 5; i++) { gpio_cfg(GPIOC, cp[i], CFG_IN_PULL); GPIOC->BSRR = PIN(cp[i]); }
        gpio_cfg(GPIOA, PA_BTN_RUN, CFG_IN_PULL); GPIOA->BSRR = PIN(PA_BTN_RUN);
        gpio_cfg(GPIOA, PA_BTN_DOWN, CFG_IN_PULL); GPIOA->BSRR = PIN(PA_BTN_DOWN);
    }
    magic = *(volatile uint32_t *)BOOT_MAGIC_ADDR;
    *(volatile uint32_t *)BOOT_MAGIC_ADDR = 0;
    delay_ms(40);
    ok_held = key_ok();
    if (magic != BOOT_MAGIC && !ok_held && app_valid()) jump_app();

    lcd_init();
    vdisk_init(); msc_init(); usb_init();

    for (;;) {
        int st;
        usb_poll(); msc_poll(); vdisk_poll(g_ms);
        st = vdisk_state();
        if (st != shown) {                                          /* new state: redraw the whole screen */
            shown = st; shown_bytes = 0xFFFFFFFFu; draw_screen(st);
            done_at = (st == VD_DONE) ? (g_ms ? g_ms : 1u) : 0;
        }
        if (st == VD_RECEIVING && (uint32_t)(g_ms - last_draw) > 150u && vdisk_bytes() != shown_bytes) {
            last_draw = g_ms; shown_bytes = vdisk_bytes(); draw_progress();
        }
        /* POWER (held 0.6 s, after it was released once so the power-on press does not count) switches off */
        if (!key_power()) { pw_armed = 1; pw_t = 0; }
        else if (pw_armed && st != VD_RECEIVING) {
            if (!pw_t) pw_t = g_ms ? g_ms : 1u;
            else if ((uint32_t)(g_ms - pw_t) > 600u) {
                lcd_fill(0, 0, LCD_W, LCD_H, C_BLACK);
                GPIOC->BRR = PIN(PC_PWR_LATCH);
                delay_ms(2000);                                     /* still running = USB powers the unit */
                shown = -1; pw_armed = 0; pw_t = 0;
            }
        }
        if (st == VD_DONE && done_at && (uint32_t)(g_ms - done_at) > 800u && key_any()) break;
        if (key_run() && st != VD_RECEIVING && st != VD_DONE && app_valid()) break;
    }
    delay_ms(100);
    if (app_valid()) { if (app_is_custom()) jump_app(); else show_restart_msg(); }
    for (;;) { }
}
