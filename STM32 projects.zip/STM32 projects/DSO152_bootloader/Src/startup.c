/* Bootloader startup: vector table, Reset_Handler, 72 MHz clock (USB needs 48 MHz = 72/1.5), SysTick 1 ms. */
#include "hw.h"
extern uint32_t _sidata, _sdata, _edata, _sbss, _ebss, _estack;
int main(void);
volatile uint32_t g_ms;
int g_clk_ok;

void *memcpy(void *d, const void *s, __SIZE_TYPE__ n) { uint8_t *a = d; const uint8_t *b = s; while (n--) *a++ = *b++; return d; }
void *memset(void *d, int v, __SIZE_TYPE__ n) { uint8_t *a = d; while (n--) *a++ = (uint8_t)v; return d; }

void SysTick_Handler(void) { g_ms++; }
/* Empty newlib system-call stubs: we use no C library I/O. Defining them here stops the linker from pulling the "nosys"
   versions, which print "_close is not implemented and will always fail" warnings (shown as build errors in CubeIDE). */
int _close(int fd) { (void)fd; return -1; }
int _lseek(int fd, int off, int whence) { (void)fd; (void)off; (void)whence; return 0; }
int _read(int fd, char *buf, int len) { (void)fd; (void)buf; (void)len; return 0; }
int _write(int fd, const char *buf, int len) { (void)fd; (void)buf; return len; }
int _fstat(int fd, void *st) { (void)fd; (void)st; return 0; }
int _isatty(int fd) { (void)fd; return 1; }
int _getpid(void) { return 1; }
int _kill(int pid, int sig) { (void)pid; (void)sig; return -1; }
void _exit(int code) { (void)code; for (;;) { } }
void *_sbrk(int incr) { (void)incr; return (void *)-1; }

void fault_report(uint32_t kind, uint32_t *frame);   /* main.c: shows the fault on the LCD */
__attribute__((naked)) void HardFault_Handler(void)
{
    __asm volatile("tst lr, #4\n\tite eq\n\tmrseq r1, msp\n\tmrsne r1, psp\n\tmov r0, #1\n\tb fault_report");
}
void Default_Handler(void) { fault_report(2, 0); for (;;) { } }
void delay_ms(uint32_t ms) { uint32_t s = g_ms; while ((uint32_t)(g_ms - s) < ms) { } }

#define HSE_MHZ 8u
void clock_init72(void)
{
    uint32_t t;
    g_clk_ok = 0;
    RCC->CR |= (1u << 16);
    for (t = 0; t < 0x20000 && !(RCC->CR & (1u << 17)); t++) { }
    if (!(RCC->CR & (1u << 17))) return;
    FLASH->ACR = 0x12;
    RCC->CFGR = (1u << 16) | ((72u / HSE_MHZ - 2u) << 18) | (4u << 8);       /* PLLSRC=HSE, x9, APB1 /2, USBPRE=0 (/1.5) */
    RCC->CR |= (1u << 24);
    for (t = 0; t < 0x20000 && !(RCC->CR & (1u << 25)); t++) { }
    if (!(RCC->CR & (1u << 25))) return;
    RCC->CFGR = (RCC->CFGR & ~3u) | 2u;
    for (t = 0; t < 0x20000 && ((RCC->CFGR >> 2) & 3u) != 2u; t++) { }
    g_clk_ok = 1;
}

void systick_start(void) { STK_LOAD = (g_clk_ok ? 72000u : 8000u) - 1u; STK_VAL = 0; STK_CTRL = 7; }

void Reset_Handler(void)
{
    uint32_t *s = &_sidata, *d = &_sdata;
    /* First thing after reset: keep the power latch (PC10) high. A software reset (app -> bootloader) releases the pin for a moment,
       and without this the instrument could switch itself off before the clock is even running. */
    RCC->APB2ENR |= RCC_APB2_IOPC;
    GPIOC->BSRR = PIN(PC_PWR_LATCH);
    gpio_cfg(GPIOC, PC_PWR_LATCH, CFG_OUT_2);
    while (d < &_edata) *d++ = *s++;
    for (d = &_sbss; d < &_ebss; d++) *d = 0;
    SCB_VTOR = 0x08000000u;                      /* may have been left pointing at the application's table */
    __asm volatile("cpsie i");                  /* and interrupts may have been left masked when the app jumped here */
    clock_init72();
    systick_start();
    main();
    for (;;) { }
}

typedef void (*isr_t)(void);
__attribute__((section(".isr_vector"), used))
const isr_t vectors[16] = {
    (isr_t)&_estack, Reset_Handler, Default_Handler, HardFault_Handler,
    HardFault_Handler, HardFault_Handler, HardFault_Handler, 0, 0, 0, 0,
    Default_Handler, Default_Handler, 0, Default_Handler, SysTick_Handler
};
