#include "hw.h"
#include "vdisk.h"
#include "flashw.h"

#define MAXS ((APP_LIMIT - APP_BASE) / 512u)       /* sectors in the application slot */

static uint8_t fat[VD_FAT_SECTORS * 512u];
static uint8_t root[VD_ROOT_SECTORS * 512u];
static uint8_t hdr[512];                           /* first sector of the image: programmed last */
static uint8_t written[(MAXS + 7u) / 8u];
static uint8_t erased[8];
static int state, active, size_known;
static uint32_t dbg_drop, dbg_err, dbg_idx;
static uint32_t first_lba, expect, file_size, got, highest, last_ms, now_ms, bytes_done;

static uint32_t get32(const uint8_t *p) { return (uint32_t)p[0] | ((uint32_t)p[1] << 8) | ((uint32_t)p[2] << 16) | ((uint32_t)p[3] << 24); }
static void put16(uint8_t *p, uint16_t v) { p[0] = (uint8_t)v; p[1] = (uint8_t)(v >> 8); }
static void put32(uint8_t *p, uint32_t v) { put16(p, (uint16_t)v); put16(p + 2, (uint16_t)(v >> 16)); }

void vdisk_init(void)
{
    memset(fat, 0, sizeof fat); memset(root, 0, sizeof root);
    fat[0] = 0xF8; fat[1] = 0xFF; fat[2] = 0xFF;
    memcpy(root, "DSO152 BOOT", 11); root[11] = 0x08;           /* volume label */
    state = VD_IDLE; active = 0; got = 0; bytes_done = 0;
}

static void make_boot(uint8_t *b)
{
    memset(b, 0, 512);
    b[0] = 0xEB; b[1] = 0x3C; b[2] = 0x90; memcpy(b + 3, "DSO152  ", 8);
    put16(b + 11, 512); b[13] = 1; put16(b + 14, 1); b[16] = 2; put16(b + 17, 32);
    put16(b + 19, (uint16_t)VD_SECTORS); b[21] = 0xF8; put16(b + 22, (uint16_t)VD_FAT_SECTORS);
    put16(b + 24, 32); put16(b + 26, 2);
    b[36] = 0x80; b[38] = 0x29; put32(b + 39, 0x20260101u);
    memcpy(b + 43, "DSO152BOOT ", 11); memcpy(b + 54, "FAT12   ", 8);
    b[510] = 0x55; b[511] = 0xAA;
}

void vdisk_read(uint32_t lba, uint8_t *buf)
{
    if (lba == 0) make_boot(buf);
    else if (lba <= VD_FAT_SECTORS) memcpy(buf, fat + (lba - 1) * 512u, 512);
    else if (lba <= 2 * VD_FAT_SECTORS) memcpy(buf, fat + (lba - 1 - VD_FAT_SECTORS) * 512u, 512);
    else if (lba < VD_DATA_LBA) memcpy(buf, root + (lba - 1 - 2 * VD_FAT_SECTORS) * 512u, 512);
    else memset(buf, 0, 512);
}

static int bit(const uint8_t *a, uint32_t i) { return (a[i >> 3] >> (i & 7u)) & 1; }
static void setbit(uint8_t *a, uint32_t i) { a[i >> 3] |= (uint8_t)(1u << (i & 7u)); }

static int header_ok(const uint8_t *b)
{
    uint32_t sp = get32(b), rs = get32(b + 4);
    return ((sp & 0xFFFE0000u) == 0x20000000u) && (rs & 1u) && rs > APP_BASE && rs < APP_LIMIT;
}

static void scan_root(void)                        /* learn the size of the file whose data we are programming */
{
    uint32_t e;
    for (e = 0; e < sizeof root / 32u; e++) {
        const uint8_t *p = root + 32u * e;
        uint32_t cl;
        if (p[0] == 0x00 || p[0] == 0xE5 || (p[11] & 0x18) || p[11] == 0x0F) continue;
        cl = (uint32_t)p[26] | ((uint32_t)p[27] << 8);
        if (active && cl == first_lba - VD_DATA_LBA + 2u && get32(p + 28) > 0) {
            file_size = get32(p + 28);
            expect = (file_size + 511u) / 512u;
            size_known = 1;
        }
    }
}

static void start_new(uint32_t lba)
{
    dbg_drop = 0; dbg_err = 0; dbg_idx = 0;
    memset(written, 0, sizeof written); memset(erased, 0, sizeof erased);
    active = 1; state = VD_RECEIVING; first_lba = lba; got = 0; highest = 0; size_known = 0; expect = 0; file_size = 0; bytes_done = 0;
}

/* Erase the whole application slot as soon as a new image starts. Erasing page by page while the data arrives costs ~35 ms per
   sector and the PC resets the port when a command takes about a second; with the pages already erased a sector needs only ~13 ms. */
static void preerase(void)
{
    uint32_t p;
    for (p = 0; p < (MAXS * 512u) / 1024u; p++) {
        if (flash_erase_page(APP_BASE + p * 1024u)) { state = VD_ERROR; dbg_err = 1; return; }
        setbit(erased, p);
    }
}

static void data_write(uint32_t lba, const uint8_t *b)
{
    uint32_t idx, page;
    int may_start = !active || state == VD_DONE || state == VD_ERROR || (now_ms - last_ms) > 3000u;
    if (may_start && header_ok(b)) { start_new(lba); preerase(); }        /* a header inside a running transfer is ignored */
    if (!active || state != VD_RECEIVING || lba < first_lba) { if (state == VD_RECEIVING || !active) dbg_drop++; return; }     /* other files written by the PC */
    idx = lba - first_lba;
    dbg_idx = idx;
    if (idx >= MAXS) { state = VD_ERROR; dbg_err = 3; return; }
    if (bit(written, idx)) return;                        /* duplicate write */
    setbit(written, idx); got++; last_ms = now_ms; bytes_done = got * 512u;
    if (idx > highest) highest = idx;
    if (idx == 0) { memcpy(hdr, b, 512); return; }
    page = (idx * 512u) / 1024u;
    if (!bit(erased, page)) {
        if (flash_erase_page(APP_BASE + page * 1024u)) { state = VD_ERROR; dbg_err = 1; return; }
        setbit(erased, page);
    }
    if (flash_program(APP_BASE + idx * 512u, b, 512)) { state = VD_ERROR; dbg_err = 2; }
}

void vdisk_write(uint32_t lba, const uint8_t *buf)
{
    if (lba == 0) return;
    if (lba <= VD_FAT_SECTORS) memcpy(fat + (lba - 1) * 512u, buf, 512);
    else if (lba <= 2 * VD_FAT_SECTORS) memcpy(fat + (lba - 1 - VD_FAT_SECTORS) * 512u, buf, 512);
    else if (lba < VD_DATA_LBA) { memcpy(root + (lba - 1 - 2 * VD_FAT_SECTORS) * 512u, buf, 512); scan_root(); }
    else data_write(lba, buf);
}

static int all_written(uint32_t n)
{
    uint32_t i;
    if (n == 0 || n > MAXS) return 0;
    for (i = 0; i < n; i++) if (!bit(written, i)) return 0;
    return 1;
}

static void finalize(uint32_t n)
{
    if (!all_written(n)) { state = VD_ERROR; return; }
    if (!bit(erased, 0)) { if (flash_erase_page(APP_BASE)) { state = VD_ERROR; return; } setbit(erased, 0); }
    if (flash_program(APP_BASE, hdr, 512)) { state = VD_ERROR; return; }
    bytes_done = size_known ? file_size : n * 512u;
    state = VD_DONE;
}

void vdisk_poll(uint32_t now)
{
    uint32_t idle, n;
    now_ms = now;
    if (!active || state != VD_RECEIVING) return;
    idle = now - last_ms;
    /* Windows updates the directory entry (file size) several times while it copies, so a size seen early may be only partial.
       Finish only when everything up to the latest known size has arrived and nothing new came for 2.5 s. */
    if (size_known && highest + 1u <= expect && all_written(expect) && idle > 2500u) { finalize(expect); return; }
    if (got >= 1 && idle > 10000u) {                     /* long silence: take what we have */
        n = (size_known && highest + 1u <= expect) ? expect : highest + 1u;
        if (all_written(n)) finalize(n); else { state = VD_ERROR; dbg_err = 4; }
    }
}

int vdisk_state(void) { return state; }
uint32_t vdisk_bytes(void) { return bytes_done; }
uint32_t vdisk_total(void) { return size_known ? file_size : 0u; }

uint32_t vdisk_dbg(int which) { return which == 0 ? dbg_err : which == 1 ? dbg_drop : which == 2 ? dbg_idx : got; }
