#include "hw.h"
#include "flashw.h"

static void unlock(void)
{
    if (FLASH->CR & (1u << 7)) { FLASH->KEYR = 0x45670123u; FLASH->KEYR = 0xCDEF89ABu; }
}
static void wait(void) { while (FLASH->SR & 1u) { } }

int flash_erase_page(uint32_t addr)
{
    uint32_t i; int err = 0;
    if (addr < APP_BASE || addr >= APP_LIMIT) return -1;           /* never touch the bootloader or the settings pages */
    unlock(); wait();
    FLASH->SR = 0x34u;                                              /* clear EOP, WRPRTERR, PGERR */
    FLASH->CR = (1u << 1); FLASH->AR = addr; FLASH->CR |= (1u << 6); wait();
    FLASH->CR = 0;
    for (i = 0; i < 1024; i += 4) if (*(volatile uint32_t *)(addr + i) != 0xFFFFFFFFu) err = 1;
    FLASH->CR = (1u << 7);
    return err;
}

int flash_program(uint32_t addr, const uint8_t *d, uint32_t len)
{
    uint32_t i; int err = 0;
    if (addr < APP_BASE || addr + len > APP_LIMIT) return -1;
    unlock(); wait();
    FLASH->SR = 0x34u;
    for (i = 0; i < len; i += 2) {
        uint16_t hw = (uint16_t)(d[i] | ((i + 1 < len ? d[i + 1] : 0xFF) << 8));
        FLASH->CR = 1u;
        *(volatile uint16_t *)(addr + i) = hw;
        wait();
        FLASH->CR = 0;
    }
    FLASH->CR = (1u << 7);
    for (i = 0; i < len; i++) if (*(volatile uint8_t *)(addr + i) != d[i]) err = 1;
    return err;
}
