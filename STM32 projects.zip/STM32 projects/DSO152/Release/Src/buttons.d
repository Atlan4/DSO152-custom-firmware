Src/buttons.o: ../Src/buttons.c ../Inc/hw.h ../Inc/buttons.h
../Inc/hw.h:
../Inc/buttons.h:
