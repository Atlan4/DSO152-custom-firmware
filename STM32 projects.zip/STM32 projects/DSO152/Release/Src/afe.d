Src/afe.o: ../Src/afe.c ../Inc/hw.h ../Inc/afe.h
../Inc/hw.h:
../Inc/afe.h:
