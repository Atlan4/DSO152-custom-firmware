Src/ui.o: ../Src/ui.c ../Inc/hw.h ../Inc/lcd.h ../Inc/ui.h ../Inc/dsp.h \
 ../Inc/afe.h
../Inc/hw.h:
../Inc/lcd.h:
../Inc/ui.h:
../Inc/dsp.h:
../Inc/afe.h:
