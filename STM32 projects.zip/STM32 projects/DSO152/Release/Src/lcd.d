Src/lcd.o: ../Src/lcd.c ../Inc/hw.h ../Inc/lcd.h ../Inc/font5x7.h
../Inc/hw.h:
../Inc/lcd.h:
../Inc/font5x7.h:
