Src/dsp.o: ../Src/dsp.c ../Inc/dsp.h
../Inc/dsp.h:
