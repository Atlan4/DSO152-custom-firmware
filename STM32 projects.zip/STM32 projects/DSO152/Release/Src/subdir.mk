################################################################################
# Automatically-generated file. Do not edit!
# Toolchain: GNU Tools for STM32 (14.3.rel1)
################################################################################

# Add inputs and outputs from these tool invocations to the build variables 
C_SRCS += \
../Src/afe.c \
../Src/battery.c \
../Src/buttons.c \
../Src/dsp.c \
../Src/flashcal.c \
../Src/font5x7.c \
../Src/lcd.c \
../Src/main.c \
../Src/startup.c \
../Src/ui.c 

OBJS += \
./Src/afe.o \
./Src/battery.o \
./Src/buttons.o \
./Src/dsp.o \
./Src/flashcal.o \
./Src/font5x7.o \
./Src/lcd.o \
./Src/main.o \
./Src/startup.o \
./Src/ui.o 

C_DEPS += \
./Src/afe.d \
./Src/battery.d \
./Src/buttons.d \
./Src/dsp.d \
./Src/flashcal.d \
./Src/font5x7.d \
./Src/lcd.d \
./Src/main.d \
./Src/startup.d \
./Src/ui.d 


# Each subdirectory must supply rules for building sources it contributes
Src/%.o Src/%.su Src/%.cyclo: ../Src/%.c Src/subdir.mk
	arm-none-eabi-gcc "$<" -mcpu=cortex-m3 -std=gnu11 -DSTM32 -DSTM32F1 -DSTM32F103R8Tx -c -I../Inc -Os -ffunction-sections -fdata-sections -Wall -fstack-usage -fcyclomatic-complexity -MMD -MP -MF"$(@:%.o=%.d)" -MT"$@" --specs=nano.specs -mfloat-abi=soft -mthumb -o "$@"

clean: clean-Src

clean-Src:
	-$(RM) ./Src/afe.cyclo ./Src/afe.d ./Src/afe.o ./Src/afe.su ./Src/battery.cyclo ./Src/battery.d ./Src/battery.o ./Src/battery.su ./Src/buttons.cyclo ./Src/buttons.d ./Src/buttons.o ./Src/buttons.su ./Src/dsp.cyclo ./Src/dsp.d ./Src/dsp.o ./Src/dsp.su ./Src/flashcal.cyclo ./Src/flashcal.d ./Src/flashcal.o ./Src/flashcal.su ./Src/font5x7.cyclo ./Src/font5x7.d ./Src/font5x7.o ./Src/font5x7.su ./Src/lcd.cyclo ./Src/lcd.d ./Src/lcd.o ./Src/lcd.su ./Src/main.cyclo ./Src/main.d ./Src/main.o ./Src/main.su ./Src/startup.cyclo ./Src/startup.d ./Src/startup.o ./Src/startup.su ./Src/ui.cyclo ./Src/ui.d ./Src/ui.o ./Src/ui.su

.PHONY: clean-Src

