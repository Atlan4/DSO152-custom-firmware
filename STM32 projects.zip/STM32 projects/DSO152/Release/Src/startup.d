Src/startup.o: ../Src/startup.c ../Inc/hw.h
../Inc/hw.h:
