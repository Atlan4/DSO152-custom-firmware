Src/main.o: ../Src/main.c ../Inc/hw.h ../Inc/lcd.h ../Inc/afe.h \
 ../Inc/dsp.h ../Inc/ui.h ../Inc/dsp.h ../Inc/buttons.h ../Inc/battery.h \
 ../Inc/flashcal.h ../Inc/afe.h
../Inc/hw.h:
../Inc/lcd.h:
../Inc/afe.h:
../Inc/dsp.h:
../Inc/ui.h:
../Inc/dsp.h:
../Inc/buttons.h:
../Inc/battery.h:
../Inc/flashcal.h:
../Inc/afe.h:
