Src/flashcal.o: ../Src/flashcal.c ../Inc/hw.h ../Inc/flashcal.h \
 ../Inc/afe.h ../Inc/dsp.h
../Inc/hw.h:
../Inc/flashcal.h:
../Inc/afe.h:
../Inc/dsp.h:
