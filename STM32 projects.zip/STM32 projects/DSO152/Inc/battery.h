#ifndef BATTERY_H
#define BATTERY_H
#include <stdint.h>

/* Divider 10k + 10k -> ADC sees Vbat/2. */
#define BATT_DIV_NUM 2u

/* Convert a raw 12-bit ADC reading to battery millivolts.
 * vdda_mv: analog supply in mV (3300 if unknown). */
uint32_t battery_mv_from_raw(uint16_t raw, uint32_t vdda_mv);

/* Li-ion open-circuit style curve, 0..100 %. */
uint8_t battery_percent_from_mv(uint32_t mv);

/* Slow low-pass filter (call once per reading, e.g. 2-4x per second).
 * Returns filtered mV. First call initialises the filter. */
uint32_t battery_filter_mv(uint32_t mv);

/* Hysteresis for display: avoids flicker between neighbouring percent values. */
uint8_t battery_display_percent(uint8_t new_percent);

#endif
