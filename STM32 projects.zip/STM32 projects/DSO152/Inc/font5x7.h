#ifndef FONT5X7_H
#define FONT5X7_H
#include <stdint.h>
/* 5x7 font, ASCII 0x20..0x7E, 5 column bytes per glyph (bit0 = top row). */
extern const uint8_t font5x7[95][5];
#endif
