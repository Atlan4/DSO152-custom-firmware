#ifndef LCD_DRIVER_H
#define LCD_DRIVER_H
#include <stdint.h>
/* Physical panel is ST7789, 240x320 portrait, 16-bit 8080 bus on GPIOB (same wiring/init as dso152tft.h).
   UI is landscape 320 x 240, rotated 90 deg clockwise from the native portrait orientation:
   MADCTL = MX | MV | BGR = 0x68 (the 0x08 BGR bit is what the working breakout sketch uses). Fixed. */
#define LCD_W 320
#define LCD_H 240
#define LCD_MADCTL 0x68

#define RGB(r,g,b) ((uint16_t)((((r) & 0xF8) << 8) | (((g) & 0xFC) << 3) | ((b) >> 3)))
#define C_BLACK  0x0000
#define C_WHITE  0xFFFF
#define C_GRID   RGB(60,60,60)
#define C_AXIS   RGB(110,110,110)
#define C_TRACE  RGB(255,230,0)
#define C_GREEN  RGB(80,255,80)
#define C_RED    RGB(255,70,70)
#define C_CYAN   RGB(80,220,255)
#define C_ORANGE RGB(255,150,0)
#define C_BLUE   RGB(120,160,255)
#define C_MAG    RGB(255,120,255)
#define C_DIM    RGB(150,150,150)
#define C_LGREEN RGB(120,255,120)
#define C_SEL    RGB(0,60,120)

void lcd_init(void);
void lcd_backlight(int on);
void lcd_window(int x0, int y0, int x1, int y1);   /* then call lcd_put() w*h times */
void lcd_put(uint16_t rgb565);
void lcd_fill(int x, int y, int w, int h, uint16_t c);
void lcd_str(int x, int y, const char *s, uint16_t fg, uint16_t bg, int scale);   /* 6x8 cell * scale */
void lcd_str16(int x, int y, const char *s, uint16_t fg, uint16_t bg);            /* 8x16 cell, size of the stock firmware */
#endif
