#ifndef BUTTONS_H
#define BUTTONS_H
#include <stdint.h>
enum { B_UP, B_DOWN, B_LEFT, B_RIGHT, B_OK, B_MODE, B_AUTO, B_RUN, B_POWER, B_COUNT };
#define LONG_PRESS_MS 1000

void buttons_init(void);
void buttons_poll(void);                 /* kept for compatibility: sampling now runs in the 1 ms SysTick interrupt */
int  btn_pressed(int b);                 /* edge: became pressed since last call (cleared on read) */
int  btn_short(int b);                   /* edge: released before the long-press time */
int  btn_long(int b);                    /* edge: held for LONG_PRESS_MS (fires once, while still held) */
int  btn_down(int b);                    /* current debounced state */
void power_hold(void);                   /* PC10 = 1: keep the board powered after the power button is released */
void power_off(void);                    /* PC10 = 0 (board turns off when the button is released) */
#endif
