/* Minimal register-level hardware definitions for STM32F103R8 / CH32F103R8 (no vendor library). */
#ifndef HW_H
#define HW_H
#include <stdint.h>
#define IO volatile

typedef struct { IO uint32_t CRL, CRH, IDR, ODR, BSRR, BRR, LCKR; } GPIO_TypeDef;
typedef struct { IO uint32_t CR, CFGR, CIR, APB2RSTR, APB1RSTR, AHBENR, APB2ENR, APB1ENR, BDCR, CSR; } RCC_TypeDef;
typedef struct { IO uint32_t EVCR, MAPR, EXTICR[4]; } AFIO_TypeDef;
typedef struct { IO uint32_t SR, CR1, CR2, SMPR1, SMPR2, JOFR[4], HTR, LTR, SQR1, SQR2, SQR3, JSQR, JDR[4], DR; } ADC_TypeDef;
typedef struct { IO uint32_t CCR, CNDTR, CPAR, CMAR, RES; } DMACh_TypeDef;
typedef struct { IO uint32_t ISR, IFCR; DMACh_TypeDef CH[7]; } DMA_TypeDef;
typedef struct { IO uint32_t CR1, CR2, SMCR, DIER, SR, EGR, CCMR1, CCMR2, CCER, CNT, PSC, ARR, RES, CCR1, CCR2, CCR3, CCR4; } TIM_TypeDef;
typedef struct { IO uint32_t ACR, KEYR, OPTKEYR, SR, CR, AR; } FLASH_TypeDef;

#define GPIOA ((GPIO_TypeDef *)0x40010800u)
#define GPIOB ((GPIO_TypeDef *)0x40010C00u)
#define GPIOC ((GPIO_TypeDef *)0x40011000u)
#define RCC   ((RCC_TypeDef *)0x40021000u)
#define AFIO  ((AFIO_TypeDef *)0x40010000u)
#define ADC1  ((ADC_TypeDef *)0x40012400u)
#define ADC2  ((ADC_TypeDef *)0x40012800u)
#define DMA1  ((DMA_TypeDef *)0x40020000u)
#define TIM2  ((TIM_TypeDef *)0x40000000u)
#define TIM3  ((TIM_TypeDef *)0x40000400u)
#define TIM4  ((TIM_TypeDef *)0x40000800u)
#define FLASH ((FLASH_TypeDef *)0x40022000u)
#define NVIC_ISER0 (*(IO uint32_t *)0xE000E100u)
#define SCB_VTOR   (*(IO uint32_t *)0xE000ED08u)
#define SCB_AIRCR  (*(IO uint32_t *)0xE000ED0Cu)
#define STK_CTRL   (*(IO uint32_t *)0xE000E010u)
#define STK_LOAD   (*(IO uint32_t *)0xE000E014u)
#define STK_VAL    (*(IO uint32_t *)0xE000E018u)

/* RCC bits */
#define RCC_APB2_AFIO  (1u << 0)
#define RCC_APB2_IOPA  (1u << 2)
#define RCC_APB2_IOPB  (1u << 3)
#define RCC_APB2_IOPC  (1u << 4)
#define RCC_APB2_ADC1  (1u << 9)
#define RCC_APB2_ADC2  (1u << 10)
#define RCC_APB1_TIM2  (1u << 0)
#define RCC_APB1_TIM3  (1u << 1)
#define RCC_APB1_TIM4  (1u << 2)
#define RCC_AHB_DMA1   (1u << 0)

/* GPIO pin configuration nibble: CNF<<2 | MODE */
#define CFG_ANALOG    0x0u
#define CFG_IN_FLOAT  0x4u
#define CFG_IN_PULL   0x8u    /* pull-up/down, select with ODR */
#define CFG_OUT_2     0x2u
#define CFG_OUT_50    0x3u
#define CFG_AF_50     0xBu

static inline void gpio_cfg(GPIO_TypeDef *g, int pin, uint32_t cfg)
{
    IO uint32_t *r = (pin < 8) ? &g->CRL : &g->CRH;
    int sh = (pin & 7) * 4;
    *r = (*r & ~(0xFu << sh)) | (cfg << sh);
}
#define PIN(n) (1u << (n))

#ifndef HOST_CHECK
#define NOP() __asm volatile("nop")
#else
#define NOP() ((void)0)
#endif

/* ---- board pin map (see DSO152 schematic pages) ---- */
/* GPIOA */ #define PA_CALIB 0   /* TIM2_CH1, 1 kHz calibration / generator */
            #define PA_ADC_IN 1
            #define PA_RELAY 2   /* 1 = 10x attenuator relay engaged (from stock firmware) */
            #define PA_ACDC  3
            #define PA_MUX_A 4   /* 4051 A (AS0), B = PA5, C = PA6 */
            #define PA_VBAT  7
            #define PA_LCD_RST 8
            #define PA_BTN_DOWN 9
            #define PA_BTN_RUN 10
            #define PA_LCD_CS 15
/* GPIOC */ #define PC_BTN_LEFT 3
            #define PC_BTN_OK 4
            #define PC_BTN_RIGHT 5
            #define PC_BTN_UP 6
            #define PC_BTN_MODE 7
            #define PC_BTN_AUTO 8
            #define PC_LCD_BL 9   /* low = backlight on */
            #define PC_PWR_LATCH 10
            #define PC_BTN_POWER 11
            #define PC_LCD_RS 13
            #define PC_LCD_WR 14
            #define PC_LCD_RD 15

void *memcpy(void *d, const void *s, __SIZE_TYPE__ n);
void *memset(void *d, int v, __SIZE_TYPE__ n);

/* timing helpers (SysTick, 1 ms) */
extern volatile uint32_t g_ms;
void delay_ms(uint32_t ms);
#endif
