#ifndef UI_H
#define UI_H
#include <stdint.h>
#include "dsp.h"

enum { TM_AUTO, TM_NORM, TM_SINGLE };
enum { TG_TIME, TG_VPOS, TG_TRIG, TG_HPOS, TG_COUNT };     /* what the rocker left/right adjusts */

typedef struct {
    int range, tb, cpl, rising, tmode, hold, view, target;
    int vpos;        /* trace position, px (+ = up) */
    int tlevel;      /* trigger level, ADC counts relative to the zero level */
    int hpos;        /* trigger position, px from the left edge of the plot */
    int gen_on, gen_fi, gen_duty;
    int bat_pct, bat_mv, roll;
    int probe;       /* 1, 10 or 100 */
} ui_state_t;

#define PLOT_X 10
#define PLOT_Y 20

void ui_init(void);                                           /* clear screen */
void ui_plot(const uint16_t *s, int n, uint32_t start_q8, uint32_t spd_q8, int zero, uint32_t klabel_q8, int vpos, int hpos_marker, uint16_t hpos_color);
void ui_markers(const ui_state_t *st, int zero, uint32_t klabel_q8);
void ui_status(const ui_state_t *st);                          /* top bar, 8x16 font */
void ui_meas(const ui_state_t *st, const dsp_stats_t *d, int zero, uint32_t k_q8, uint32_t phys_x10);
void ui_message(const char *l1, const char *l2, const char *l3);
void ui_title(const char *t);
void ui_row(int row, const char *label, const char *value, int selected);
#endif
