#ifndef DSP_H
#define DSP_H
#include <stdint.h>

#define N_SAMPLES 1024
#define N_SAMPLES_MAX 2048        /* fast (dual ADC) mode captures 2048 samples */
#define PLOT_W 300
#define PLOT_H 160
#define PX_DIV 20                 /* pixels per vertical division (8 divisions) */
#define PRE_TRIG 60
#define DEFAULT_ZERO 2065        /* ADC counts at 0 V (stock calibration data was around 2063..2069) */
#define DEFAULT_K_Q8 (500u * 256u) /* ADC counts per division, <<8; refined by "gain calibration" */

typedef struct {
    int32_t vmax, vmin;       /* ADC counts */
    int32_t avg_x16;          /* average counts * 16 */
    uint32_t rms;             /* RMS of (sample - zero) in counts */
    int have_freq;
    uint32_t freq_mhz;        /* milli-Hertz */
    uint32_t period_us;       /* cycle time */
    uint32_t wpos_us, wneg_us;/* positive / negative pulse width */
    int duty_pos_x10, duty_neg_x10;   /* 0.1 % units */
    int clipped;
} dsp_stats_t;

int  dsp_find_trigger(const uint16_t *b, int n, int from, int to, int level, int hyst, int rising);
void dsp_analyze(const uint16_t *b, int n, uint64_t ts_ns, int zero, dsp_stats_t *o);   /* ts_ns: sample period */
int32_t dsp_counts_to_mv(int32_t counts, uint32_t phys_x10, uint32_t k_q8);   /* phys_x10: real mV/div * 10 */
int  dsp_y(int sample, int zero, uint32_t klabel_q8, int vpos);   /* pixel row 0..PLOT_H-1; klabel = counts per labelled div << 8 */
int  dsp_interp(const uint16_t *b, int n, uint32_t pos_q8);       /* linear interpolation at a fractional sample position */
uint32_t dsp_isqrt64(uint64_t v);

/* text formatting helpers (no libc) */
void fmt_volt(char *out, int32_t mv);                      /* e.g. "1.23V", "456mV" */
void fmt_freq(char *out, uint32_t mhz);                    /* e.g. "1.000kHz", "50.00Hz" */
void fmt_uint(char *out, uint32_t v);
void fmt_vdiv(char *out, uint32_t mv);                     /* e.g. "10mV", "2V", "1KV" */
void fmt_time(char *out, uint32_t us);                     /* e.g. "1.000ms", "250us", "1.500s" */
void fmt_pct10(char *out, int x10);                        /* 0.1 % units -> "50.0%" */
#endif
