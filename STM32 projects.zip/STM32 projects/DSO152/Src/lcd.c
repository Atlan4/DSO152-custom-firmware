/* ST7789 parallel driver. Pin handling copied from dso152tft.h (breakout project):
   data PB0..PB15, RS=PC13, WR=PC14, RD=PC15, CS=PA15, RST=PA8, backlight=PC9 (low = on).
   Colour quirk of this panel: display is in INVON mode and bytes are written as toBGR(~colour). */
#include "hw.h"
#include "lcd.h"
#include "font5x7.h"

#define RS_B PIN(PC_LCD_RS)
#define WR_B PIN(PC_LCD_WR)
#define RD_B PIN(PC_LCD_RD)

static inline uint16_t raw(uint16_t c)
{
    c = (uint16_t)~c;
    return (uint16_t)(((c & 0x1F) << 11) | (c & 0x07E0) | ((c >> 11) & 0x1F));   /* swap R and B */
}

void lcd_put(uint16_t rgb565)
{
    GPIOB->ODR = raw(rgb565);
    GPIOC->BRR = WR_B; NOP(); NOP();
    GPIOC->BSRR = WR_B; NOP();
}

static void wr(uint16_t v)          /* write one bus word (data) */
{
    GPIOB->ODR = v;
    GPIOC->BRR = WR_B; NOP(); NOP();
    GPIOC->BSRR = WR_B; NOP();
}

static void cmd(uint8_t c)
{
    GPIOC->BRR = RS_B;
    wr(c);
    GPIOC->BSRR = RS_B;
}

static void cmd_args(uint8_t c, const uint8_t *a, int n)
{
    cmd(c);
    while (n--) wr(*a++);
}

void lcd_window(int x0, int y0, int x1, int y1)
{
    cmd(0x2A); wr((uint16_t)(x0 >> 8)); wr((uint16_t)(x0 & 0xFF)); wr((uint16_t)(x1 >> 8)); wr((uint16_t)(x1 & 0xFF));
    cmd(0x2B); wr((uint16_t)(y0 >> 8)); wr((uint16_t)(y0 & 0xFF)); wr((uint16_t)(y1 >> 8)); wr((uint16_t)(y1 & 0xFF));
    cmd(0x2C);
}

void lcd_fill(int x, int y, int w, int h, uint16_t c)
{
    uint32_t n = (uint32_t)w * (uint32_t)h;
    if (w <= 0 || h <= 0) return;
    lcd_window(x, y, x + w - 1, y + h - 1);
    GPIOB->ODR = raw(c);
    while (n--) { GPIOC->BRR = WR_B; NOP(); NOP(); GPIOC->BSRR = WR_B; NOP(); }
}

void lcd_backlight(int on)
{
    if (on) GPIOC->BRR = PIN(PC_LCD_BL); else GPIOC->BSRR = PIN(PC_LCD_BL);      /* PC9, low = on */
}

void lcd_init(void)
{
    static const uint8_t arg_colmod[] = { 0x55 };
    uint8_t madctl[1];
    uint8_t caset[4], raset[4];

    RCC->APB2ENR |= RCC_APB2_AFIO | RCC_APB2_IOPA | RCC_APB2_IOPB | RCC_APB2_IOPC;
    AFIO->MAPR = (AFIO->MAPR & ~(7u << 24)) | (2u << 24);       /* JTAG off, SWD on: frees PA15, PB3, PB4 */

    gpio_cfg(GPIOA, PA_LCD_CS, CFG_OUT_50);  gpio_cfg(GPIOA, PA_LCD_RST, CFG_OUT_50);
    gpio_cfg(GPIOC, PC_LCD_RS, CFG_OUT_50);  gpio_cfg(GPIOC, PC_LCD_WR, CFG_OUT_50);
    gpio_cfg(GPIOC, PC_LCD_RD, CFG_OUT_50);  gpio_cfg(GPIOC, PC_LCD_BL, CFG_OUT_50);
    GPIOB->CRL = 0x33333333u; GPIOB->CRH = 0x33333333u;

    GPIOC->BSRR = PIN(PC_LCD_BL);                 /* backlight off while initialising */
    GPIOA->BRR  = PIN(PA_LCD_CS);                 /* CS permanently low */
    GPIOA->BSRR = PIN(PA_LCD_RST);
    GPIOC->BSRR = RS_B | RD_B | WR_B;

    cmd(0x01); delay_ms(150);                     /* SWRESET */
    cmd(0x11); delay_ms(10);                      /* SLPOUT */
    cmd_args(0x3A, arg_colmod, 1); delay_ms(10);  /* COLMOD: 16 bit */
    madctl[0] = LCD_MADCTL; cmd_args(0x36, madctl, 1);
    caset[0] = 0; caset[1] = 0; caset[2] = ((LCD_W - 1) >> 8); caset[3] = ((LCD_W - 1) & 0xFF);
    raset[0] = 0; raset[1] = 0; raset[2] = ((LCD_H - 1) >> 8); raset[3] = ((LCD_H - 1) & 0xFF);
    cmd_args(0x2A, caset, 4);
    cmd_args(0x2B, raset, 4);
    cmd(0x21); delay_ms(10);                      /* INVON (needed on this panel) */
    cmd(0x13); delay_ms(10);                      /* NORON */
    cmd(0x29); delay_ms(10);                      /* DISPON */
    lcd_fill(0, 0, LCD_W, LCD_H, C_BLACK);
    lcd_backlight(1);
}

void lcd_str(int x, int y, const char *s, uint16_t fg, uint16_t bg, int scale)
{
    for (; *s; s++, x += 6 * scale) {
        int ch = (unsigned char)*s, col, row, sx, sy;
        const uint8_t *g;
        if (ch < 0x20 || ch > 0x7E) ch = '?';
        g = font5x7[ch - 0x20];
        lcd_window(x, y, x + 6 * scale - 1, y + 8 * scale - 1);
        for (row = 0; row < 8; row++)
            for (sy = 0; sy < scale; sy++)
                for (col = 0; col < 6; col++) {
                    uint16_t c = (col < 5 && row < 7 && ((g[col] >> row) & 1)) ? fg : bg;
                    for (sx = 0; sx < scale; sx++) lcd_put(c);
                }
    }
}

/* 8x16 text: the 5x7 font is stretched to 7x14 inside an 8x16 cell (same cell size as the stock firmware). */
void lcd_str16(int x, int y, const char *s, uint16_t fg, uint16_t bg)
{
    static const uint8_t colmap[8] = { 0, 1, 1, 2, 3, 3, 4, 5 };   /* 5 = blank column */
    for (; *s; s++, x += 8) {
        int ch = (unsigned char)*s, row, col;
        const uint8_t *g;
        if (ch < 0x20 || ch > 0x7E) ch = '?';
        g = font5x7[ch - 0x20];
        lcd_window(x, y, x + 7, y + 15);
        for (row = 0; row < 16; row++) {
            int sr = (row - 1) >> 1, rowok = (row >= 1 && row <= 14);
            for (col = 0; col < 8; col++) {
                int cm = colmap[col];
                lcd_put((rowok && cm < 5 && ((g[cm] >> sr) & 1)) ? fg : bg);
            }
        }
    }
}
