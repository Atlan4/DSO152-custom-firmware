/* Startup code: vector table, Reset_Handler, clock setup, SysTick. */
#include "hw.h"

extern uint32_t _sidata, _sdata, _edata, _sbss, _ebss, _estack, __isr_vector_start;
int main(void);

volatile uint32_t g_ms;

void *memcpy(void *d, const void *s, __SIZE_TYPE__ n) { uint8_t *a = d; const uint8_t *b = s; while (n--) *a++ = *b++; return d; }
void *memset(void *d, int v, __SIZE_TYPE__ n) { uint8_t *a = d; while (n--) *a++ = (uint8_t)v; return d; }

void buttons_tick(void);
void SysTick_Handler(void) { g_ms++; buttons_tick(); }   /* buttons are sampled and debounced here, independent of the main loop */
/* Empty newlib system-call stubs: we use no C library I/O. Defining them here stops the linker from pulling the "nosys"
   versions, which print "_close is not implemented and will always fail" warnings (shown as build errors in CubeIDE). */
int _close(int fd) { (void)fd; return -1; }
int _lseek(int fd, int off, int whence) { (void)fd; (void)off; (void)whence; return 0; }
int _read(int fd, char *buf, int len) { (void)fd; (void)buf; (void)len; return 0; }
int _write(int fd, const char *buf, int len) { (void)fd; (void)buf; return len; }
int _fstat(int fd, void *st) { (void)fd; (void)st; return 0; }
int _isatty(int fd) { (void)fd; return 1; }
int _getpid(void) { return 1; }
int _kill(int pid, int sig) { (void)pid; (void)sig; return -1; }
void _exit(int code) { (void)code; for (;;) { } }
void *_sbrk(int incr) { (void)incr; return (void *)-1; }

void Default_Handler(void) { for (;;) { } }

#define HSE_MHZ 8u   /* crystal frequency; PLL multiplies to 72 MHz */

static void clock_init(void)
{
    uint32_t t;
    RCC->CR |= (1u << 16);                                   /* HSEON */
    for (t = 0; t < 0x5000 && !(RCC->CR & (1u << 17)); t++) { }
    if (RCC->CR & (1u << 17)) {
        FLASH->ACR = 0x12;                                   /* prefetch + 2 wait states */
        RCC->CFGR = (1u << 16) | ((72u / HSE_MHZ - 2u) << 18) /* PLLSRC=HSE, PLLMUL */
                  | (4u << 8)                                /* APB1 = /2 (36 MHz) */
                  | (2u << 14);                              /* ADC clock = PCLK2/6 = 12 MHz */
        RCC->CR |= (1u << 24);                               /* PLLON */
        for (t = 0; t < 0x5000 && !(RCC->CR & (1u << 25)); t++) { }
        if (RCC->CR & (1u << 25)) {
            RCC->CFGR = (RCC->CFGR & ~3u) | 2u;              /* SYSCLK = PLL */
            for (t = 0; t < 0x5000 && ((RCC->CFGR >> 2) & 3u) != 2u; t++) { }
        }
    }
}

void delay_ms(uint32_t ms) { uint32_t s = g_ms; while ((uint32_t)(g_ms - s) < ms) { } }

void Reset_Handler(void)
{
    uint32_t *s = &_sidata, *d = &_sdata;
    while (d < &_edata) *d++ = *s++;
    for (d = &_sbss; d < &_ebss; d++) *d = 0;
    SCB_VTOR = (uint32_t)&__isr_vector_start;   /* our vector table, address comes from the linker script */
    clock_init();
    STK_LOAD = 72000u - 1u;          /* 1 ms tick at 72 MHz */
    STK_VAL = 0;
    STK_CTRL = 7;
    main();
    for (;;) { }
}

typedef void (*isr_t)(void);
__attribute__((section(".isr_vector"), used))
const isr_t vectors[76] = {
    (isr_t)&_estack, Reset_Handler, Default_Handler, Default_Handler,   /* SP, Reset, NMI, HardFault */
    Default_Handler, Default_Handler, Default_Handler, 0, 0, 0, 0,      /* MemManage, BusFault, UsageFault, reserved */
    Default_Handler, Default_Handler, 0, Default_Handler, SysTick_Handler,
    /* external interrupts 0..59: all default */
    [16 ... 75] = Default_Handler
};
