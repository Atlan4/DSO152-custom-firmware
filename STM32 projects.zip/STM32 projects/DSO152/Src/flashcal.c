#include "hw.h"
#include "flashcal.h"
#include "dsp.h"

static uint32_t checksum(const cal_t *c)
{
    const uint16_t *p = (const uint16_t *)c; uint32_t s = 0x5A5Au; unsigned i;
    for (i = 0; i < (sizeof(cal_t) - 4) / 2; i++) s = (s << 1 | s >> 31) ^ p[i];
    return s;
}

void cal_defaults_user(cal_t *c)
{
    static const int16_t d[U_COUNT] = { 6, 6, 0, 1, 0, 0, 0, 0, 60, 0, 9, 50, 100, 1, 0, 0 };
    int i;
    for (i = 0; i < U_COUNT; i++) c->user[i] = d[i];
}

void cal_defaults(cal_t *c)
{
    int i;
    c->magic = CAL_MAGIC; c->pad = 0xFFFF; c->k_q8 = DEFAULT_K_Q8;
    for (i = 0; i < AFE_NRANGES; i++) c->zero[i] = DEFAULT_ZERO;
    cal_defaults_user(c);
    c->check = checksum(c);
}

int cal_load(cal_t *c)
{
    const cal_t *f = (const cal_t *)CAL_ADDR;
    if (f->magic == CAL_MAGIC && f->check == checksum(f)) { *c = *f; return 1; }
    cal_defaults(c);
    return 0;
}

static void fwait(void) { while (FLASH->SR & 1u) { } }

int cal_save(const cal_t *src)
{
    cal_t c = *src; const uint16_t *p = (const uint16_t *)&c; unsigned i; int ok = 1;
    c.magic = CAL_MAGIC; c.check = checksum(&c);
    FLASH->KEYR = 0x45670123u; FLASH->KEYR = 0xCDEF89ABu;
    fwait();
    FLASH->CR = (1u << 1); FLASH->AR = CAL_ADDR; FLASH->CR |= (1u << 6); fwait();   /* PER, STRT */
    FLASH->CR = 0;
    for (i = 0; i < sizeof(cal_t) / 2; i++) {
        FLASH->CR = 1u;                                      /* PG */
        *(IO uint16_t *)(CAL_ADDR + 2u * i) = p[i];
        fwait();
        FLASH->CR = 0;
    }
    FLASH->CR = (1u << 7);                                   /* LOCK */
    for (i = 0; i < sizeof(cal_t) / 2; i++) if (((const uint16_t *)CAL_ADDR)[i] != p[i]) ok = 0;
    return ok;
}
