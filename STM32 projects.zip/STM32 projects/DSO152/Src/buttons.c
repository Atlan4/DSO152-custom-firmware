#include "hw.h"
#include "buttons.h"

typedef struct { GPIO_TypeDef *port; uint8_t pin; } btn_t;
static const btn_t map[B_COUNT] = {
    { GPIOC, PC_BTN_UP }, { GPIOA, PA_BTN_DOWN }, { GPIOC, PC_BTN_LEFT }, { GPIOC, PC_BTN_RIGHT },
    { GPIOC, PC_BTN_OK }, { GPIOC, PC_BTN_MODE }, { GPIOC, PC_BTN_AUTO }, { GPIOA, PA_BTN_RUN }, { GPIOC, PC_BTN_POWER }
};
static volatile uint8_t state[B_COUNT], ev_press[B_COUNT], ev_short[B_COUNT], ev_long[B_COUNT];
static uint8_t cnt[B_COUNT], long_fired[B_COUNT];
static uint16_t held[B_COUNT], rep[B_COUNT];
static volatile uint8_t ready;

void power_hold(void)
{
    RCC->APB2ENR |= RCC_APB2_IOPC;
    GPIOC->BSRR = PIN(PC_PWR_LATCH);
    gpio_cfg(GPIOC, PC_PWR_LATCH, CFG_OUT_2);
}

void power_off(void) { GPIOC->BRR = PIN(PC_PWR_LATCH); }

void buttons_init(void)
{
    int i;
    RCC->APB2ENR |= RCC_APB2_IOPA | RCC_APB2_IOPC;
    for (i = 0; i < B_COUNT; i++) {
        gpio_cfg(map[i].port, map[i].pin, CFG_IN_PULL);
        map[i].port->BSRR = PIN(map[i].pin);                 /* pull-up */
    }
    ready = 1;
}

/* Called from SysTick every millisecond. 5 ms debounce, 1 s long press, auto-repeat on the four direction keys. */
void buttons_tick(void)
{
    int i;
    if (!ready) return;
    for (i = 0; i < B_COUNT; i++) {
        int raw = !(map[i].port->IDR & PIN(map[i].pin));     /* active low */
        if (raw != state[i]) {
            if (++cnt[i] >= 5) {
                cnt[i] = 0; state[i] = (uint8_t)raw;
                if (raw) { ev_press[i] = 1; held[i] = 0; rep[i] = 0; long_fired[i] = 0; }
                else if (!long_fired[i]) ev_short[i] = 1;
            }
        } else cnt[i] = 0;
        if (state[i]) {
            if (held[i] < 60000u) held[i]++;
            if (!long_fired[i] && held[i] >= LONG_PRESS_MS) { long_fired[i] = 1; ev_long[i] = 1; }
            if (i <= B_RIGHT && held[i] >= 400u && ++rep[i] >= 100u) { rep[i] = 0; ev_press[i] = 1; }   /* auto-repeat */
        }
    }
}

void buttons_poll(void) { }
int btn_down(int b) { return state[b]; }
int btn_pressed(int b) { int v = ev_press[b]; ev_press[b] = 0; return v; }
int btn_short(int b) { int v = ev_short[b]; ev_short[b] = 0; return v; }
int btn_long(int b) { int v = ev_long[b]; ev_long[b] = 0; return v; }
