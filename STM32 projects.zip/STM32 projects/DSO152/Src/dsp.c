/* Signal processing and formatting: pure C, no hardware access (unit tested on the PC). */
#include "dsp.h"

uint32_t dsp_isqrt64(uint64_t v)
{
    uint64_t r = 0, bit = 1ull << 62;
    while (bit > v) bit >>= 2;
    while (bit) {
        if (v >= r + bit) { v -= r + bit; r = (r >> 1) + bit; } else r >>= 1;
        bit >>= 2;
    }
    return (uint32_t)r;
}

int dsp_find_trigger(const uint16_t *b, int n, int from, int to, int level, int hyst, int rising)
{
    int i, armed = 0;
    if (from < 1) from = 1;
    if (to > n - 1) to = n - 1;
    for (i = from - 1; i <= to; i++) {
        int v = b[i];
        if (i >= from && armed && (rising ? (v >= level) : (v <= level))) return i;
        if (rising) { if (v < level - hyst) armed = 1; }
        else        { if (v > level + hyst) armed = 1; }
    }
    return -1;
}

void dsp_analyze(const uint16_t *b, int n, uint64_t ts_ns, int zero, dsp_stats_t *o)
{
    int i, mn = 65535, mx = 0, level, hyst, up = 0, dn = 0, cnt = 0, high_cnt = 0;
    uint32_t sum = 0;
    uint64_t sq = 0;
    int64_t first_pos = 0, last_pos = 0, last_rise = -1, high_sum = 0;

    for (i = 0; i < n; i++) {
        int v = b[i], d = v - zero;
        if (v < mn) mn = v;
        if (v > mx) mx = v;
        sum += (uint32_t)v;
        sq += (uint64_t)((int64_t)d * d);
    }
    o->vmax = mx; o->vmin = mn;
    o->avg_x16 = (int32_t)(((uint64_t)sum * 16u) / (uint32_t)n);
    o->rms = dsp_isqrt64(sq / (uint32_t)n);
    o->clipped = (mn <= 2 || mx >= 4093);
    o->have_freq = 0; o->freq_mhz = 0; o->period_us = 0; o->wpos_us = 0; o->wneg_us = 0;
    o->duty_pos_x10 = 0; o->duty_neg_x10 = 0;
    if (mx - mn < 10) return;

    level = (mx + mn) / 2;
    hyst = (mx - mn) / 16; if (hyst < 3) hyst = 3;
    for (i = 1; i < n; i++) {
        int v = b[i], p = b[i - 1];
        if (up && v >= level && p < level) {                      /* rising crossing */
            int64_t pos = (int64_t)(i - 1) * 256 + ((int64_t)(level - p) * 256) / (v - p);
            if (cnt == 0) first_pos = pos;
            last_pos = pos; last_rise = pos; cnt++;
            up = 0;
        }
        if (dn && v < level && p >= level) {                      /* falling crossing */
            int64_t pos = (int64_t)(i - 1) * 256 + ((int64_t)(p - level) * 256) / (p - v);
            if (last_rise >= 0) { high_sum += pos - last_rise; high_cnt++; last_rise = -1; }
            dn = 0;
        }
        if (v < level - hyst) up = 1;
        if (v > level + hyst) dn = 1;
    }
    if (cnt >= 2 && last_pos > first_pos) {
        int64_t per = (last_pos - first_pos) / (cnt - 1);         /* period in 1/256 samples */
        if (per <= 0 || ts_ns == 0) return;
        o->have_freq = 1;
        o->freq_mhz = (uint32_t)(256000000000000ull / ((uint64_t)per * ts_ns));
        o->period_us = (uint32_t)((uint64_t)per * ts_ns / 256000ull);
        if (high_cnt > 0) {
            int64_t w = high_sum / high_cnt;
            if (w > per) w = per;
            o->wpos_us = (uint32_t)((uint64_t)w * ts_ns / 256000ull);
            o->wneg_us = o->period_us > o->wpos_us ? o->period_us - o->wpos_us : 0;
            o->duty_pos_x10 = (int)((w * 1000) / per);
            o->duty_neg_x10 = 1000 - o->duty_pos_x10;
        }
    }
}

int32_t dsp_counts_to_mv(int32_t counts, uint32_t phys_x10, uint32_t k_q8)
{
    return (int32_t)(((int64_t)counts * 256 * (int64_t)phys_x10) / ((int64_t)k_q8 * 10));
}

int dsp_y(int sample, int zero, uint32_t klabel_q8, int vpos)
{
    int32_t d = (int32_t)(sample - zero) * PX_DIV * 256;
    int y = PLOT_H / 2 - vpos - (int)(d / (int32_t)klabel_q8);
    if (y < 0) y = 0;
    if (y > PLOT_H - 1) y = PLOT_H - 1;
    return y;
}

int dsp_interp(const uint16_t *b, int n, uint32_t pos_q8)
{
    int i = (int)(pos_q8 >> 8), f = (int)(pos_q8 & 255);
    if (i >= n - 1) return b[n - 1];
    return b[i] + (((int)b[i + 1] - (int)b[i]) * f) / 256;
}

void fmt_uint(char *out, uint32_t v)
{
    char t[11]; int n = 0;
    do { t[n++] = (char)('0' + v % 10u); v /= 10u; } while (v);
    while (n) *out++ = t[--n];
    *out = 0;
}

static char *put(char *o, const char *s) { while (*s) *o++ = *s++; return o; }
static char *putu(char *o, uint32_t v, int digits)   /* zero padded to `digits` (0 = no padding) */
{
    char t[11]; int n = 0;
    do { t[n++] = (char)('0' + v % 10u); v /= 10u; } while (v);
    while (n < digits) t[n++] = '0';
    while (n) *o++ = t[--n];
    return o;
}

void fmt_volt(char *out, int32_t mv)
{
    char *o = out; uint32_t a;
    if (mv < 0) { *o++ = '-'; a = (uint32_t)(-mv); } else a = (uint32_t)mv;
    if (a >= 1000000u)    { o = putu(o, a / 1000000u, 0); *o++ = '.'; o = putu(o, (a % 1000000u) / 10000u, 2); o = put(o, "KV"); }
    else if (a >= 10000u) { o = putu(o, a / 1000u, 0); *o++ = '.'; o = putu(o, (a % 1000u) / 100u, 1); o = put(o, "V"); }
    else if (a >= 1000u)  { o = putu(o, a / 1000u, 0); *o++ = '.'; o = putu(o, (a % 1000u) / 10u, 2); o = put(o, "V"); }
    else                  { o = putu(o, a, 0); o = put(o, "mV"); }
    *o = 0;
}

void fmt_freq(char *out, uint32_t mhz)
{
    char *o = out; uint32_t hz = mhz / 1000u;
    if (hz >= 1000000u)    { o = putu(o, hz / 1000000u, 0); *o++ = '.'; o = putu(o, (hz % 1000000u) / 1000u, 3); o = put(o, "MHz"); }
    else if (hz >= 1000u)  { o = putu(o, hz / 1000u, 0); *o++ = '.'; o = putu(o, hz % 1000u, 3); o = put(o, "kHz"); }
    else if (hz >= 10u)    { o = putu(o, hz, 0); *o++ = '.'; o = putu(o, (mhz % 1000u) / 10u, 2); o = put(o, "Hz"); }
    else                   { o = putu(o, hz, 0); *o++ = '.'; o = putu(o, mhz % 1000u, 3); o = put(o, "Hz"); }
    *o = 0;
}

void fmt_time(char *out, uint32_t us)
{
    char *o = out;
    if (us >= 1000000u)      { o = putu(o, us / 1000000u, 0); *o++ = '.'; o = putu(o, (us % 1000000u) / 1000u, 3); o = put(o, "s"); }
    else if (us >= 1000u)    { o = putu(o, us / 1000u, 0); *o++ = '.'; o = putu(o, us % 1000u, 3); o = put(o, "ms"); }
    else                     { o = putu(o, us, 0); o = put(o, "us"); }
    *o = 0;
}

void fmt_pct10(char *out, int x10)
{
    char *o = out;
    if (x10 < 0) x10 = 0;
    o = putu(o, (uint32_t)x10 / 10u, 0); *o++ = '.'; o = putu(o, (uint32_t)x10 % 10u, 1); o = put(o, "%");
    *o = 0;
}

void fmt_vdiv(char *out, uint32_t mv)
{
    char *o = out;
    if (mv >= 1000000u)      { o = putu(o, mv / 1000000u, 0); o = put(o, "KV"); }
    else if (mv >= 1000u)    { o = putu(o, mv / 1000u, 0); o = put(o, "V"); }
    else                     { o = putu(o, mv, 0); o = put(o, "mV"); }
    *o = 0;
}
