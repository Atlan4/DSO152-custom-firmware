#include "battery.h"

uint32_t battery_mv_from_raw(uint16_t raw, uint32_t vdda_mv)
{
    if (raw > 4095u) raw = 4095u;
    return ((uint32_t)raw * vdda_mv * BATT_DIV_NUM + 2047u) / 4095u;
}

/* mV -> % table (typical 3.7 V Li-ion, light load). Descending. */
static const struct { uint16_t mv; uint8_t pct; } curve[] = {
    {4200,100},{4150, 95},{4110, 90},{4080, 85},{4020, 80},{3980, 75},
    {3950, 70},{3910, 65},{3870, 60},{3850, 55},{3840, 50},{3820, 45},
    {3800, 40},{3790, 35},{3770, 30},{3750, 25},{3730, 20},{3710, 15},
    {3690, 10},{3610,  5},{3270,  0}
};
#define NCURVE (sizeof curve / sizeof curve[0])

uint8_t battery_percent_from_mv(uint32_t mv)
{
    unsigned i;
    if (mv >= curve[0].mv) return 100;
    if (mv <= curve[NCURVE - 1].mv) return 0;
    for (i = 1; i < NCURVE; i++) {
        if (mv >= curve[i].mv) {
            uint32_t hi = curve[i - 1].mv, lo = curve[i].mv;
            uint32_t ph = curve[i - 1].pct, pl = curve[i].pct;
            return (uint8_t)(pl + ((mv - lo) * (ph - pl) + (hi - lo) / 2) / (hi - lo));
        }
    }
    return 0;
}

uint32_t battery_filter_mv(uint32_t mv)
{
    static uint32_t acc; static uint8_t init;
    if (!init) { acc = mv << 4; init = 1; }
    else       { acc = acc - (acc >> 4) + mv; }      /* y += (x - y)/16 */
    return acc >> 4;
}

uint8_t battery_display_percent(uint8_t p)
{
    static int shown = -1;
    if (shown < 0) shown = p;
    else if (p >= shown + 2 || p + 2 <= shown) shown = p;   /* change only by >=2 %  */
    else if (p == 100 || p == 0) shown = p;
    return (uint8_t)shown;
}
